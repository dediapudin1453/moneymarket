<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-02 06:12:33 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-05-02 06:15:46 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-05-02 06:27:58 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-05-02 06:30:36 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
