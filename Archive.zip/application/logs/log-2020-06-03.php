<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 12:22:36 --> Could not find the language line "referral_title"
ERROR - 2020-06-03 12:22:36 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-06-03 12:22:36 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-06-03 12:22:36 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
