<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-04 07:22:02 --> Severity: Notice --> Undefined property: stdClass::$CONTENT /home/u8936188/public_html/demo-profile-bisnis-6/application/views/themes/profile-bisnis-6-04079a0188efb5358214f0f0cb4dd07e/home.php 24
ERROR - 2019-12-04 07:22:02 --> Severity: Notice --> Undefined property: stdClass::$CONTENT /home/u8936188/public_html/demo-profile-bisnis-6/application/views/themes/profile-bisnis-6-04079a0188efb5358214f0f0cb4dd07e/home.php 24
ERROR - 2019-12-04 10:37:18 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-6/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-04 11:00:19 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-6/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-04 07:26:17 --> Query error: Table 'u8936188_profile-7.t_setting' doesn't exist - Invalid query: SELECT `value`
FROM `t_setting`
WHERE `options` = 'timezone'
ERROR - 2019-12-04 15:04:31 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-7/application/views/mod/homepage/view_edit.php 35
