<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-21 07:50:11 --> Query error: Table 'wwforex-dev.t_product_category' doesn't exist - Invalid query: SELECT *
FROM `t_product_category`
ERROR - 2021-01-21 07:50:25 --> Query error: Table 'wwforex-dev.t_product_category' doesn't exist - Invalid query: SELECT *
FROM `t_product_category`
ERROR - 2021-01-21 07:50:30 --> Query error: Table 'wwforex-dev.t_product_category' doesn't exist - Invalid query: SELECT *
FROM `t_product_category`
ERROR - 2021-01-21 08:11:54 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-21 08:27:18 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 08:27:18 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 121
ERROR - 2021-01-21 08:27:18 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 132
ERROR - 2021-01-21 08:27:18 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 138
ERROR - 2021-01-21 08:27:23 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 08:27:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:20:57 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:21:01 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:21:19 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:21:20 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:26:32 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/controllers/l-member/Account.php 475
ERROR - 2021-01-21 09:26:34 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/controllers/l-member/Account.php 475
ERROR - 2021-01-21 09:31:02 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/controllers/l-member/Account.php 475
ERROR - 2021-01-21 09:51:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:51:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:51:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:51:29 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:53:07 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:53:40 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:56:47 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 09:57:14 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:00:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:00:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:01:08 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:07:37 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:07:39 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:07:54 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:07:55 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:08:13 --> Could not find the language line "form_label_title"
ERROR - 2021-01-21 10:08:17 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:08:20 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:08:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:08:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:15:15 --> Could not find the language line "form_label_title"
ERROR - 2021-01-21 10:21:16 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:21:22 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:21:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:21:34 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:21:34 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 121
ERROR - 2021-01-21 10:21:34 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 132
ERROR - 2021-01-21 10:21:34 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 138
ERROR - 2021-01-21 10:22:00 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:22:00 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:23:50 --> Could not find the language line "form_label_title"
ERROR - 2021-01-21 10:24:09 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:25:52 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:25:54 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:32:12 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:32:42 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:32:59 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:33:07 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:34:33 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:34:38 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:41:40 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/controllers/l-member/Account.php 475
ERROR - 2021-01-21 10:41:44 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:41:47 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:42:21 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:42:21 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:44:06 --> Could not find the language line "form_label_title"
ERROR - 2021-01-21 10:44:23 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:44:44 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:44:44 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:45:29 --> Could not find the language line "form_label_title"
ERROR - 2021-01-21 10:45:41 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:47:49 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:47:59 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:48:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:48:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:57:40 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:59:42 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:59:43 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:59:53 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:59:53 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 10:59:56 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 11:00:01 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 11:00:09 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 11:00:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 11:00:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 11:02:48 --> Could not find the language line "form_label_title"
ERROR - 2021-01-21 11:02:55 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 11:04:14 --> Could not find the language line "referral_title"
ERROR - 2021-01-21 11:07:36 --> Could not find the language line "referral_title"
