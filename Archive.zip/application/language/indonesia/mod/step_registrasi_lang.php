<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Akun';
$lang['mod_title_all'] = 'Semua Akun';
$lang['mod_title_add'] = 'Tambah Akun';
$lang['mod_title_edit'] = 'Ubah Akun';
$lang['table_id'] = 'Id';
$lang['table_title'] = 'Judul';
$lang['table_seotitle'] = 'Sub Judul';
$lang['table_active'] = 'Akif';
$lang['table_action'] = 'Aksi';
$lang['form_label_title'] = 'Judul';
$lang['form_label_seotitle'] = 'Judul Seo';
$lang['form_label_content'] = 'Konten';
$lang['form_label_picture'] = 'Gambar';
$lang['form_label_active'] = 'Aktif';
$lang['form_message_add_success'] = 'Data Akun dan Layanan telah berhasil ditambahkan';
$lang['form_message_update_success'] = 'Data Akun dan Layanan telah berhasil diperbarui';
$lang['form_message_delete_success'] = 'Data Akun dan Layanan telah berhasil dihapus';