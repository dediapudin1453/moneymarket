<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-19 11:03:57 --> Could not find the language line "referral_title"
ERROR - 2020-05-19 11:04:33 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 475
ERROR - 2020-05-19 11:05:03 --> Could not find the language line "referral_title"
ERROR - 2020-05-19 11:05:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-19 11:07:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-19 11:07:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-19 11:14:49 --> Could not find the language line "form_label_title"
ERROR - 2020-05-19 11:14:49 --> Query error: Column 'wallet_id' cannot be null - Invalid query: INSERT INTO `t_wallet_history` (`wallet_id`, `amount_before`, `amount`, `amount_after`, `source`, `deposit_id`) VALUES (NULL, NULL, '619.20', 619.2, 'Deposit', 7)
ERROR - 2020-05-19 11:14:57 --> Could not find the language line "form_label_title"
ERROR - 2020-05-19 11:15:05 --> Could not find the language line "form_label_title"
ERROR - 2020-05-19 11:15:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-19 11:15:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-19 19:38:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-19 19:38:38 --> Could not find the language line "referral_title"
