<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-29 18:54:30 --> Query error: Table 'webpraktis.t_product' doesn't exist - Invalid query: SELECT *
FROM `t_product`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 18:56:05 --> Query error: Table 'webpraktis.t_product' doesn't exist - Invalid query: SELECT *
FROM `t_product`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 18:56:37 --> Query error: Table 'webpraktis.t_product' doesn't exist - Invalid query: SELECT *
FROM `t_product`
ORDER BY `id` DESC
ERROR - 2019-10-29 13:50:23 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kerjaan\websitepraktis\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kerjaan\websitepraktis\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kerjaan\websitepraktis\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kerjaan\websitepraktis\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kerjaan\websitepraktis\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2019-10-29 13:50:23 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2019-10-29 20:22:49 --> Could not find the language line "table_active"
ERROR - 2019-10-29 20:23:16 --> Could not find the language line "table_active"
ERROR - 2019-10-29 20:53:51 --> Query error: Unknown column 'nama' in 'field list' - Invalid query: INSERT INTO `t_testimoni` (`nama`, `comment`, `picture`, `active`) VALUES ('Dyah', '&lt;p&gt;Wah bagus sekali&lt;/p&gt;', 'seo-grey.png', 'Y')
ERROR - 2019-10-29 20:56:12 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\testimoni\view_edit.php 34
ERROR - 2019-10-29 20:56:12 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\testimoni\view_edit.php 35
ERROR - 2019-10-29 20:56:12 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\testimoni\view_edit.php 47
ERROR - 2019-10-29 20:56:45 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\testimoni\view_edit.php 35
ERROR - 2019-10-29 20:56:45 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\testimoni\view_edit.php 47
ERROR - 2019-10-29 20:57:07 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\testimoni\view_edit.php 35
ERROR - 2019-10-29 21:33:54 --> Could not find the language line "table_section"
ERROR - 2019-10-29 21:33:54 --> Could not find the language line "table_content"
ERROR - 2019-10-29 21:33:55 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 33
ERROR - 2019-10-29 21:33:55 --> Severity: Notice --> Undefined index: comment C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 35
ERROR - 2019-10-29 21:33:55 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 37
ERROR - 2019-10-29 21:33:55 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 39
ERROR - 2019-10-29 21:33:55 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 33
ERROR - 2019-10-29 21:33:55 --> Severity: Notice --> Undefined index: comment C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 35
ERROR - 2019-10-29 21:33:55 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 37
ERROR - 2019-10-29 21:33:55 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 39
ERROR - 2019-10-29 21:33:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\kerjaan\websitepraktis\system\core\Exceptions.php:271) C:\xampp\htdocs\kerjaan\websitepraktis\system\core\Common.php 570
ERROR - 2019-10-29 21:39:28 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 37
ERROR - 2019-10-29 21:39:28 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Homepage.php 37
ERROR - 2019-10-29 21:46:06 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%CT%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 21:46:09 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%CTA%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 21:46:29 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%C%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 21:47:21 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%t%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 21:47:27 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%te%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 21:47:34 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%ten%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 21:48:38 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 34
ERROR - 2019-10-29 21:48:38 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 35
ERROR - 2019-10-29 21:48:38 --> Severity: Notice --> Undefined index: comment C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 47
ERROR - 2019-10-29 21:48:38 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 64
ERROR - 2019-10-29 21:49:14 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 35
ERROR - 2019-10-29 21:49:14 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 64
ERROR - 2019-10-29 21:49:31 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 35
ERROR - 2019-10-29 21:49:31 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 64
ERROR - 2019-10-29 21:50:21 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 35
ERROR - 2019-10-29 21:50:21 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\kerjaan\websitepraktis\application\views\mod\homepage\view_edit.php 64
ERROR - 2019-10-29 21:51:04 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%T%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 21:51:09 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%C%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2019-10-29 21:51:14 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE   (
`title` LIKE '%Ce%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
