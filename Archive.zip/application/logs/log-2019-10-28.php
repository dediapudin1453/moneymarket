<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-28 12:16:24 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Slider.php 57
ERROR - 2019-10-28 18:34:19 --> Severity: error --> Exception: Call to undefined method Slider_model::get_pages() C:\xampp\htdocs\kerjaan\websitepraktis\application\controllers\l-admin\Slider.php 155
