<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-03 04:10:17 --> Severity: error --> Exception: syntax error, unexpected '$' C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 33
ERROR - 2021-05-03 04:10:22 --> Severity: error --> Exception: syntax error, unexpected ''</div>'' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 33
ERROR - 2021-05-03 04:10:30 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 33
ERROR - 2021-05-03 04:10:31 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 33
ERROR - 2021-05-03 04:10:50 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 33
ERROR - 2021-05-03 04:10:51 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 33
ERROR - 2021-05-03 04:13:43 --> Severity: error --> Exception: syntax error, unexpected '$no' (T_VARIABLE) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 34
ERROR - 2021-05-03 04:13:51 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 34
ERROR - 2021-05-03 09:14:03 --> Severity: Notice --> Undefined variable: no C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 31
ERROR - 2021-05-03 09:21:33 --> Could not find the language line "form_label_title"
ERROR - 2021-05-03 09:21:45 --> Could not find the language line "form_label_title"
ERROR - 2021-05-03 14:30:45 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 48
ERROR - 2021-05-03 14:30:45 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 48
ERROR - 2021-05-03 14:30:45 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 48
ERROR - 2021-05-03 14:30:45 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 48
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Notice --> Undefined index: status_request2 C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\linggafx\system\core\Exceptions.php:271) C:\xampp\htdocs\linggafx\system\core\Common.php 570
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Account_trading.php 46
ERROR - 2021-05-03 14:34:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\linggafx\system\core\Exceptions.php:271) C:\xampp\htdocs\linggafx\system\core\Common.php 570
ERROR - 2021-05-03 14:44:46 --> Query error: Table 'linggafx.t_trainer' doesn't exist - Invalid query: SELECT *
FROM `t_trainer`
WHERE `active` = 'Y'
ERROR - 2021-05-03 14:45:00 --> Query error: Table 'linggafx.t_trainer' doesn't exist - Invalid query: SELECT *
FROM `t_trainer`
WHERE `active` = 'Y'
ERROR - 2021-05-03 14:45:03 --> Query error: Table 'linggafx.t_trainer' doesn't exist - Invalid query: SELECT *
FROM `t_trainer`
WHERE `active` = 'Y'
ERROR - 2021-05-03 14:45:18 --> Query error: Table 'linggafx.t_slidericon' doesn't exist - Invalid query: SELECT *
FROM `t_slidericon`
WHERE `active` = 'Y'
ERROR - 2021-05-03 14:50:27 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-05-03 14:51:12 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-05-03 14:52:52 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-05-03 14:53:14 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-05-03 14:53:14 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-05-03 14:58:27 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-05-03 15:00:13 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-05-03 15:06:11 --> Query error: Unknown column 'seotitle' in 'order clause' - Invalid query: SELECT *
FROM `t_homepage`
ORDER BY `seotitle` ASC
 LIMIT 10
ERROR - 2021-05-03 15:06:14 --> Query error: Unknown column 'seotitle' in 'order clause' - Invalid query: SELECT *
FROM `t_homepage`
ORDER BY `seotitle` DESC
 LIMIT 10
ERROR - 2021-05-03 15:06:17 --> Query error: Unknown column 'title' in 'order clause' - Invalid query: SELECT *
FROM `t_homepage`
ORDER BY `title` ASC
 LIMIT 10
ERROR - 2021-05-03 15:09:43 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
