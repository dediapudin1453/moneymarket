<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-30 14:50:40 --> Query error: Column 'os' cannot be null - Invalid query: INSERT INTO `t_visitor` (`ip`, `platform`, `os`, `browser`, `country`, `city`, `date`, `hits`, `url`) VALUES ('54.70.15.75', '', NULL, '', 'Others', 'Others', '2021-10-30', 1, '/')
