<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-16 03:29:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN `t_account_receiver` ON `t_account_receiver`.`account_id`!=`t_account_tradi' at line 2 - Invalid query: SELECT `t_account_trading`.`id` as `id`, `username`, `account`
JOIN `t_account_receiver` ON `t_account_receiver`.`account_id`!=`t_account_trading`.`id`
JOIN `t_user` ON `t_user`.`id`=`t_account_trading`.`user_id`
WHERE `t_account_trading`.`id` != 't_account_receiver.account_id'
ORDER BY `t_account_trading`.`id` DESC
 LIMIT 10
ERROR - 2020-05-16 03:40:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN `t_account_receiver` ON `t_account_receiver`.`account_id`!=`t_account_tradi' at line 2 - Invalid query: SELECT `t_account_trading`.`id` as `id`, `username`, `account`
JOIN `t_account_receiver` ON `t_account_receiver`.`account_id`!=`t_account_trading`.`id`
JOIN `t_user` ON `t_user`.`id`=`t_account_trading`.`user_id`
WHERE `t_account_trading`.`id` != 't_account_receiver.account_id'
ORDER BY `t_account_trading`.`id` DESC
ERROR - 2020-05-16 03:41:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN `t_account_receiver` ON `t_account_receiver`.`account_id`=`t_account_tradin' at line 2 - Invalid query: SELECT `t_account_trading`.`id` as `id`, `username`, `account`
JOIN `t_account_receiver` ON `t_account_receiver`.`account_id`=`t_account_trading`.`id`
JOIN `t_user` ON `t_user`.`id`=`t_account_trading`.`user_id`
WHERE `t_account_trading`.`id` != 't_account_receiver.account_id'
ORDER BY `t_account_trading`.`id` DESC
ERROR - 2020-05-16 04:01:17 --> Severity: Notice --> Undefined property: Account_receiver::$post_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 156
ERROR - 2020-05-16 04:01:17 --> Severity: error --> Exception: Call to a member function get_all_category() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 156
ERROR - 2020-05-16 04:11:36 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 04:11:36 --> Could not find the language line "form_label_subtitle"
ERROR - 2020-05-16 04:11:36 --> Could not find the language line "form_label_content"
ERROR - 2020-05-16 04:11:36 --> Could not find the language line "form_label_content"
ERROR - 2020-05-16 04:11:36 --> Could not find the language line "form_label_active"
ERROR - 2020-05-16 04:11:36 --> Could not find the language line "form_label_picture"
ERROR - 2020-05-16 04:11:36 --> Could not find the language line "form_label_picture"
ERROR - 2020-05-16 04:13:32 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 04:13:50 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 04:22:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Account_trader_model /home/qx59rn1k06vg/public_html/system/core/Loader.php 348
ERROR - 2020-05-16 04:22:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Account_trader_model /home/qx59rn1k06vg/public_html/system/core/Loader.php 348
ERROR - 2020-05-16 04:22:35 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 04:22:35 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 04:23:08 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 04:23:08 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 04:24:02 --> Query error: Unknown column 'account' in 'field list' - Invalid query: SELECT `id`, `account`
FROM `t_account_receiver`
WHERE `account` = 'a'
ERROR - 2020-05-16 04:26:38 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 04:26:38 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 04:39:02 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 04:39:02 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 04:39:09 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 04:39:09 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 05:09:09 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:09:09 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 05:09:13 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:09:13 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 05:09:28 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:09:28 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 05:11:21 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:11:21 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 05:11:54 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:11:54 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 05:11:58 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:11:58 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 05:13:38 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:13:38 --> Could not find the language line "form_validation__cek_add_account"
ERROR - 2020-05-16 05:14:30 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:14:30 --> Severity: Warning --> Use of undefined constant FLASE - assumed 'FLASE' (this will throw an Error in a future version of PHP) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 191
ERROR - 2020-05-16 05:14:49 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:14:49 --> Severity: Warning --> Use of undefined constant FLASE - assumed 'FLASE' (this will throw an Error in a future version of PHP) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 191
ERROR - 2020-05-16 05:15:07 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:15:07 --> Severity: Warning --> Use of undefined constant FLASE - assumed 'FLASE' (this will throw an Error in a future version of PHP) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 191
ERROR - 2020-05-16 05:15:47 --> Severity: Warning --> Use of undefined constant FLASE - assumed 'FLASE' (this will throw an Error in a future version of PHP) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 191
ERROR - 2020-05-16 05:16:08 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:16:19 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:24:13 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:24:29 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:24:29 --> Severity: error --> Exception: Too few arguments to function Account_receiver_model::cek_account2(), 0 passed in /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php on line 84 and exactly 1 expected /home/qx59rn1k06vg/public_html/application/models/mod/Account_receiver_model.php 169
ERROR - 2020-05-16 05:25:31 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:25:31 --> Query error: Unknown column 'acocunt_id' in 'field list' - Invalid query: INSERT INTO `t_account_receiver` (`acocunt_id`) VALUES ('1')
ERROR - 2020-05-16 05:26:48 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:30:35 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:31:54 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:32:14 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:38:27 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:38:57 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:39:53 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:40:12 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:40:12 --> Severity: Notice --> Undefined variable: cek /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 98
ERROR - 2020-05-16 05:40:12 --> Query error: Unknown column 'acocunt_id' in 'field list' - Invalid query: INSERT INTO `t_account_receiver` (`acocunt_id`) VALUES (NULL)
ERROR - 2020-05-16 05:41:13 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:41:17 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:41:17 --> Severity: Notice --> Undefined variable: cek /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 98
ERROR - 2020-05-16 05:41:17 --> Query error: Unknown column 'acocunt_id' in 'field list' - Invalid query: INSERT INTO `t_account_receiver` (`acocunt_id`) VALUES (NULL)
ERROR - 2020-05-16 05:41:35 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:41:35 --> Query error: Unknown column 'acocunt_id' in 'field list' - Invalid query: INSERT INTO `t_account_receiver` (`acocunt_id`) VALUES ('1')
ERROR - 2020-05-16 05:42:32 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:45:40 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:45:40 --> Query error: Unknown column 'acocunt_id' in 'field list' - Invalid query: INSERT INTO `t_account_receiver` (`acocunt_id`) VALUES ('1')
ERROR - 2020-05-16 05:46:34 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:46:58 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:46:58 --> Query error: Unknown column 'acount_id' in 'field list' - Invalid query: INSERT INTO `t_account_receiver` (`acount_id`) VALUES ('1')
ERROR - 2020-05-16 05:47:33 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:47:33 --> Severity: Notice --> Undefined variable: account_id /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 107
ERROR - 2020-05-16 05:47:59 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:48:21 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:54:02 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:54:11 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:55:01 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:55:58 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:56:08 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:56:14 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:57:54 --> Severity: Notice --> Undefined variable: cekAcc /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 69
ERROR - 2020-05-16 05:59:41 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 05:59:44 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 06:00:02 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 06:00:07 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 06:02:07 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 06:02:15 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 06:02:20 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 06:09:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:16:32 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 06:16:40 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 06:28:53 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:28:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Account_trading_model /home/qx59rn1k06vg/public_html/system/core/Loader.php 348
ERROR - 2020-05-16 06:29:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:33:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:33:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:33:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:35:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:37:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:37:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:39:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:41:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:41:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:53:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:53:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:10 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:26 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 06:54:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:17:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:17:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:17:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:17:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:17:28 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `t_user` (`user_id`, `from_tf`, `to_tf`, `amount`, `status`) VALUES ('10', '7891239928', 'Wallet', '100', 'Pending')
ERROR - 2020-05-16 07:18:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:18:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:18:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:18:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:19:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:19:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:19:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:10 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:10 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:31 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:31 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:20:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 00:45:49 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ']' /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 88
ERROR - 2020-05-16 00:46:26 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ']' /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 88
ERROR - 2020-05-16 00:46:28 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ']' /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 88
ERROR - 2020-05-16 00:46:48 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 98
ERROR - 2020-05-16 07:47:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:47:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:47:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:47:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:47:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:47:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:47:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:48:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:48:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:53:35 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:53:46 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:53:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:54:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 00:55:38 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 218
ERROR - 2020-05-16 00:55:51 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 218
ERROR - 2020-05-16 00:55:52 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 218
ERROR - 2020-05-16 00:55:53 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 218
ERROR - 2020-05-16 07:56:09 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:56:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:56:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:57:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 07:57:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 08:15:20 --> Severity: Notice --> Undefined index: username /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 36
ERROR - 2020-05-16 08:15:20 --> Severity: Notice --> Undefined index: amount_usd /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 40
ERROR - 2020-05-16 08:15:46 --> Severity: Notice --> Undefined index: username /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 36
ERROR - 2020-05-16 08:15:46 --> Severity: Notice --> Undefined index: amount_usd /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 40
ERROR - 2020-05-16 08:17:20 --> Severity: Notice --> Undefined index: amount_usd /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 40
ERROR - 2020-05-16 08:29:52 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `t_internal_transfer`
JOIN `t_user` ON `t_user`.`id`=`t_internal_transfer`.`user_id`
WHERE `id` = 1
ERROR - 2020-05-16 08:30:07 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/mod/internal_transfer/view_edit.php 39
ERROR - 2020-05-16 08:30:07 --> Severity: Notice --> Undefined index: owner_name /home/qx59rn1k06vg/public_html/application/views/mod/internal_transfer/view_edit.php 43
ERROR - 2020-05-16 09:45:11 --> Could not find the language line "table_amount"
ERROR - 2020-05-16 09:45:11 --> Could not find the language line "table_amount"
ERROR - 2020-05-16 03:13:17 --> Severity: error --> Exception: syntax error, unexpected 'array' (T_ARRAY) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 193
ERROR - 2020-05-16 10:14:33 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:33 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:35 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:35 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:36 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:36 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:36 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:36 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:36 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:36 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:36 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:36 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:37 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:37 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:37 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:37 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:42 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:42 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:43 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:43 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:43 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:43 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:44 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:44 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:44 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:44 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:44 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:44 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:44 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:44 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:44 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:44 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:44 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:44 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:45 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:45 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:45 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:45 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:45 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:45 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:14:45 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:14:45 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:16:51 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:16:51 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:16:54 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:16:54 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:16:54 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:16:54 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:16:54 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:16:54 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:16:55 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:16:55 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:16:55 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:16:55 --> Severity: Notice --> Undefined variable: wdlalu /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 129
ERROR - 2020-05-16 10:17:56 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:18:13 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:18:18 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:18:18 --> Severity: Notice --> Undefined variable: response /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 397
ERROR - 2020-05-16 10:18:19 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:19:34 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:19:34 --> Severity: Notice --> Undefined variable: wallet /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 333
ERROR - 2020-05-16 10:19:34 --> Severity: Notice --> Undefined property: Internal_transfer::$account_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 346
ERROR - 2020-05-16 10:19:34 --> Severity: error --> Exception: Call to a member function update() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 346
ERROR - 2020-05-16 10:26:32 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:29:15 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 10:34:20 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 12:56:42 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 12:57:38 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 12:57:38 --> Severity: Notice --> Undefined variable: wallet /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 334
ERROR - 2020-05-16 12:57:40 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 12:57:40 --> Severity: Notice --> Undefined variable: wallet /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 334
ERROR - 2020-05-16 12:57:40 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 12:57:40 --> Severity: Notice --> Undefined variable: wallet /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 334
ERROR - 2020-05-16 12:58:56 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 12:59:44 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 12:59:56 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:00:17 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:00:28 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:01:05 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:01:05 --> Severity: Notice --> Undefined property: Internal_transfer::$account_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 347
ERROR - 2020-05-16 13:01:05 --> Severity: error --> Exception: Call to a member function update() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 347
ERROR - 2020-05-16 13:03:01 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:03:51 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:04:23 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:15:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:15:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:15:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:16:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:16:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:16:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:16:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:16:31 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:16:35 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:17:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:17:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 13:17:24 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:18:17 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:18:17 --> Severity: Notice --> Undefined property: Internal_transfer::$account_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 196
ERROR - 2020-05-16 13:18:17 --> Severity: error --> Exception: Call to a member function update() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 196
ERROR - 2020-05-16 13:18:21 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:25:15 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:27:53 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 13:28:35 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:09:04 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:10:53 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:15:15 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:15:15 --> Severity: Notice --> Undefined property: Internal_transfer::$acco_receiver_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 221
ERROR - 2020-05-16 14:15:15 --> Severity: error --> Exception: Call to a member function get_account_receiver() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 221
ERROR - 2020-05-16 14:17:26 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:17:26 --> Severity: Notice --> Undefined property: Internal_transfer::$acco_receiver_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 221
ERROR - 2020-05-16 14:17:26 --> Severity: error --> Exception: Call to a member function get_account_receiver() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 221
ERROR - 2020-05-16 14:18:10 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:18:10 --> Severity: Notice --> Undefined property: Internal_transfer::$acco_receiver_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 221
ERROR - 2020-05-16 14:18:10 --> Severity: error --> Exception: Call to a member function get_account_receiver() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 221
ERROR - 2020-05-16 07:19:02 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 264
ERROR - 2020-05-16 07:20:07 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 265
ERROR - 2020-05-16 07:20:09 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 265
ERROR - 2020-05-16 14:20:51 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:22:21 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:22:21 --> Severity: Notice --> Undefined property: Internal_transfer::$acco_receiver_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 222
ERROR - 2020-05-16 14:22:21 --> Severity: error --> Exception: Call to a member function get_account_receiver() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 222
ERROR - 2020-05-16 14:22:22 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:22:22 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:36:01 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:36:01 --> Severity: Notice --> Undefined property: Internal_transfer::$acco_receiver_model /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 222
ERROR - 2020-05-16 14:36:01 --> Severity: error --> Exception: Call to a member function get_account_receiver() on null /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 222
ERROR - 2020-05-16 14:37:38 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:42:57 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:42:57 --> Severity: error --> Exception: Call to undefined method Account_receiver_model::get_account_receiver() /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 222
ERROR - 2020-05-16 14:43:00 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:43:00 --> Severity: error --> Exception: Call to undefined method Account_receiver_model::get_account_receiver() /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 222
ERROR - 2020-05-16 14:43:49 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:43:49 --> Severity: error --> Exception: Call to undefined method Account_receiver_model::get_account_receiver() /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 222
ERROR - 2020-05-16 14:44:41 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:44:48 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:44:48 --> Severity: error --> Exception: Call to undefined method Account_receiver_model::get_account_receiver() /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 222
ERROR - 2020-05-16 14:45:26 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:46:33 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:47:15 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:47:15 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:47:15 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-05-16 14:48:39 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:48:39 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:48:39 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-05-16 14:50:02 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:50:02 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:50:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 14:51:21 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:51:21 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:51:21 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-05-16 14:51:22 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:51:22 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:51:22 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-05-16 14:51:22 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:51:22 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:51:22 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-05-16 14:51:22 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:51:22 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:51:22 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-05-16 14:56:13 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:56:13 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:56:13 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2020-05-16 14:58:05 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:58:50 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:58:50 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:58:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 14:59:55 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:59:55 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:59:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 14:59:58 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:59:58 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:59:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 14:59:58 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:59:58 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:59:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 14:59:59 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:59:59 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:59:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 14:59:59 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:59:59 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:59:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 14:59:59 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:59:59 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:59:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 14:59:59 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 14:59:59 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 14:59:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 15:00:10 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 15:00:10 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 15:00:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 15:00:10 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 15:00:10 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 15:00:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 15:00:11 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 15:00:11 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 15:00:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 15:00:11 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 15:00:11 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 15:00:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 15:00:11 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 15:00:11 --> Severity: Notice --> Undefined property: Internal_transfer::$table /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-16 15:00:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = '1'' at line 2 - Invalid query: SELECT *
WHERE `id` = '1'
ERROR - 2020-05-16 15:00:37 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 08:01:18 --> Severity: error --> Exception: syntax error, unexpected 'wallet' (T_STRING) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Internal_transfer.php 269
ERROR - 2020-05-16 15:02:10 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 15:03:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:03:16 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:03:16 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:03:16 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:06:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:06:30 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:07:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:07:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:07:31 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 15:07:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:07:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:08:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:08:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:08:19 --> Could not find the language line "form_label_title"
ERROR - 2020-05-16 15:33:19 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:33:22 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:33:22 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:33:22 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:36:57 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:36:58 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:36:58 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:36:58 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:37:48 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:37:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:37:49 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:37:49 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:37:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:37:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:37:56 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:37:56 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:38:03 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:38:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:38:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:39:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:39:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:39:28 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:39:28 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:39:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:39:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:39:43 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:39:43 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:40:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:40:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:40:15 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:40:15 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:40:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:40:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:40:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:40:56 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:40:56 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:42:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:43:26 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:43:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 15:43:27 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 15:43:27 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 18:26:57 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:26:58 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:26:58 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 18:26:58 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-16 18:31:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:31:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:31:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:31:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:31:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:37:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:37:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:37:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:37:18 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:37:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:42:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:43:03 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:43:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:43:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:44:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:44:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:44:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 18:44:26 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:00:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:00:44 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: SELECT *
FROM `t_withdraw`
WHERE `userid` = '10'
ERROR - 2020-05-16 19:01:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:01:01 --> Query error: Column 'user_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `t_deposit`
JOIN `t_bank` ON `t_bank`.`id`=`t_deposit`.`bank_id`
WHERE `user_id` = '10'
ERROR - 2020-05-16 19:02:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:02:52 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `t_user`
WHERE `user_id` = '10'
ERROR - 2020-05-16 19:05:35 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 31
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: amount /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 32
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 33
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 31
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: amount /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 32
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 33
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 31
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: amount /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 32
ERROR - 2020-05-16 19:05:35 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 33
ERROR - 2020-05-16 19:06:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:08:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:08:35 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:08:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 31
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: amount /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 32
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 33
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 31
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: amount /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 32
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 33
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 31
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: amount /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 32
ERROR - 2020-05-16 19:08:36 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 33
ERROR - 2020-05-16 19:09:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:10:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:10:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:11:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:11:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:11:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:11:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:11:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:12:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:13:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:13:20 --> Query error: Unknown column 'rate' in 'field list' - Invalid query: SELECT `bank_name`, `amount`, `rate`, `amount_usdt_deposit`.`date`, `t_deposit`.`status`
FROM `t_deposit`
JOIN `t_bank` ON `t_bank`.`id`=`t_deposit`.`bank_id`
WHERE `t_deposit`.`user_id` = '10'
ERROR - 2020-05-16 19:14:16 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:14:16 --> Query error: Column 'amount' in field list is ambiguous - Invalid query: SELECT `bank_name`, `amount`, `rate`, `amount_usdt_deposit`.`date`, `t_deposit`.`status`
FROM `t_deposit`
JOIN `t_bank` ON `t_bank`.`id`=`t_deposit`.`bank_id`
JOIN `t_rate` ON `t_rate`.`id`=`t_deposit`.`t_rate_id`
WHERE `t_deposit`.`user_id` = '10'
ERROR - 2020-05-16 19:14:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:14:21 --> Query error: Column 'amount' in field list is ambiguous - Invalid query: SELECT `bank_name`, `amount`, `rate`, `amount_usdt_deposit`.`date`, `t_deposit`.`status`
FROM `t_deposit`
JOIN `t_bank` ON `t_bank`.`id`=`t_deposit`.`bank_id`
JOIN `t_rate` ON `t_rate`.`id`=`t_deposit`.`t_rate_id`
WHERE `t_deposit`.`user_id` = '10'
ERROR - 2020-05-16 19:14:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:14:39 --> Query error: Unknown column 'rate' in 'field list' - Invalid query: SELECT `bank_name`, `t_deposit`.`amount`, `rate`, `amount_usd`, `t_deposit`.`date`, `t_deposit`.`status`
FROM `t_deposit`
JOIN `t_bank` ON `t_bank`.`id`=`t_deposit`.`bank_id`
JOIN `t_rate` ON `t_rate`.`id`=`t_deposit`.`t_rate_id`
WHERE `t_deposit`.`user_id` = '10'
ERROR - 2020-05-16 19:14:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:14:41 --> Query error: Unknown column 'rate' in 'field list' - Invalid query: SELECT `bank_name`, `t_deposit`.`amount`, `rate`, `amount_usd`, `t_deposit`.`date`, `t_deposit`.`status`
FROM `t_deposit`
JOIN `t_bank` ON `t_bank`.`id`=`t_deposit`.`bank_id`
JOIN `t_rate` ON `t_rate`.`id`=`t_deposit`.`t_rate_id`
WHERE `t_deposit`.`user_id` = '10'
ERROR - 2020-05-16 19:23:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:23:13 --> Query error: Unknown column 't_deposit.t_rate_id' in 'on clause' - Invalid query: SELECT `bank_name`, `t_deposit`.`amount`, `rate_amount`, `amount_usd`, `t_deposit`.`date`, `t_deposit`.`status`
FROM `t_deposit`
JOIN `t_bank` ON `t_bank`.`id`=`t_deposit`.`bank_id`
JOIN `t_rate` ON `t_rate`.`id`=`t_deposit`.`t_rate_id`
WHERE `t_deposit`.`user_id` = '10'
ERROR - 2020-05-16 19:23:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:23:33 --> Severity: Notice --> Undefined index: rate /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 36
ERROR - 2020-05-16 19:23:33 --> Severity: Notice --> Undefined index: rate /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 36
ERROR - 2020-05-16 19:23:33 --> Severity: Notice --> Undefined index: rate /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 36
ERROR - 2020-05-16 19:23:46 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:45:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:46:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:47:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:48:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:48:09 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:48:09 --> Severity: Notice --> Undefined variable: WD /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 73
ERROR - 2020-05-16 19:48:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 73
ERROR - 2020-05-16 19:48:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:48:25 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 77
ERROR - 2020-05-16 19:48:25 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 77
ERROR - 2020-05-16 19:48:25 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 77
ERROR - 2020-05-16 19:48:25 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 77
ERROR - 2020-05-16 19:48:25 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 77
ERROR - 2020-05-16 19:48:25 --> Severity: Notice --> Undefined index: bank_name /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 77
ERROR - 2020-05-16 19:48:48 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:48:48 --> Query error: Column 'user_id' in where clause is ambiguous - Invalid query: SELECT `bank_name`, `t_withdraw`.`amount`, `rate_amount`, `amount_usd`, `t_withdraw`.`date`, `t_withdraw`.`status`
FROM `t_withdraw`
JOIN `t_bank` ON `t_bank`.`id`=`t_withdraw`.`bank_id`
WHERE `user_id` = '10'
ERROR - 2020-05-16 19:49:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:53:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 19:53:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:01:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: from_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 119
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: to_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 120
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: from_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 119
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: to_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 120
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: from_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 119
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: to_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 120
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: from_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 119
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: to_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 120
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: from_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 119
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: to_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 120
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: from_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 119
ERROR - 2020-05-16 20:01:41 --> Severity: Notice --> Undefined index: to_tf /home/qx59rn1k06vg/public_html/application/views/member/history_report.php 120
ERROR - 2020-05-16 20:02:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:18:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:18:22 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:18:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:18:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:19:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:19:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:19:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:38:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:38:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:38:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:38:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:41:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:41:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:41:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:41:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:42:16 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:42:16 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:42:19 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:42:19 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:42:22 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:43:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:44:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:44:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:44:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:47:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:56:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 20:56:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 23:34:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-16 23:34:34 --> Could not find the language line "referral_title"
