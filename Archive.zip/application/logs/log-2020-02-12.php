<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-12 15:30:30 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-14/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-02-12 15:43:00 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-14/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-02-12 15:54:36 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-14/application/views/mod/testimoni/view_edit.php 35
ERROR - 2020-02-12 15:54:41 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-14/application/views/mod/testimoni/view_edit.php 35
