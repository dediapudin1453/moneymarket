<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-29 13:41:16 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `t_activity` (`user_id`, `type`, `activity`) VALUES (NULL, 'Logout', 'Logout')
