<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-21 10:56:47 --> Could not find the language line "form_label_title"
ERROR - 2021-02-21 10:57:03 --> Could not find the language line "form_label_title"
ERROR - 2021-02-21 11:04:52 --> Could not find the language line "table_title"
ERROR - 2021-02-21 11:04:52 --> Could not find the language line "table_content"
