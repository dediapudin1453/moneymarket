<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-31 07:56:51 --> Severity: error --> Exception: syntax error, unexpected end of file /home/u1476998/public_html/demoforex/application/controllers/l-member/Login.php 119
ERROR - 2021-07-31 14:59:47 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 14:59:55 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:07:25 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:07:25 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:07:56 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:07:58 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:07:58 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:12:36 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:12:36 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:16:08 --> Severity: Notice --> Undefined variable: data /home/u1476998/public_html/demoforex/application/controllers/l-member/Account.php 488
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:19:30 --> Severity: Notice --> Undefined index: status_data /home/u1476998/public_html/demoforex/application/controllers/l-admin/Member.php 41
ERROR - 2021-07-31 15:24:06 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:24:12 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:24:14 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:24:15 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:24:25 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:24:27 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 08:30:14 --> Severity: Compile Error --> Cannot declare class Deposit, because the name is already in use /home/u1476998/public_html/demoforex/application/controllers/l-admin/Deposit.php 0
ERROR - 2021-07-31 08:30:34 --> Severity: Compile Error --> Cannot declare class Deposit, because the name is already in use /home/u1476998/public_html/demoforex/application/controllers/l-admin/Deposit.php 0
ERROR - 2021-07-31 08:31:34 --> Severity: Compile Error --> Cannot declare class Deposit, because the name is already in use /home/u1476998/public_html/demoforex/application/controllers/l-admin/Deposit.php 0
ERROR - 2021-07-31 08:31:35 --> Severity: Compile Error --> Cannot declare class Deposit, because the name is already in use /home/u1476998/public_html/demoforex/application/controllers/l-admin/Deposit.php 0
ERROR - 2021-07-31 08:31:36 --> Severity: Compile Error --> Cannot declare class Deposit, because the name is already in use /home/u1476998/public_html/demoforex/application/controllers/l-admin/Deposit.php 0
ERROR - 2021-07-31 15:32:18 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 15:32:36 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:32:37 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:32:39 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:32:57 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:32:59 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:33:23 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 15:33:45 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:33:48 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:35:26 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:35:28 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:35:32 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:35:32 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:35:34 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:35:39 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:35:42 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:36:13 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:36:15 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:36:17 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:36:21 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:36:22 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:49:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Point_member_model /home/u1476998/public_html/demoforex/system/core/Loader.php 348
ERROR - 2021-07-31 15:49:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Point_member_model /home/u1476998/public_html/demoforex/system/core/Loader.php 348
ERROR - 2021-07-31 15:50:11 --> Severity: Notice --> Undefined index: server /home/u1476998/public_html/demoforex/application/views/mod/account_trading/view_edit.php 89
ERROR - 2021-07-31 15:51:14 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 15:51:21 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:51:47 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:51:51 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:51:52 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:53:02 --> Query error: Unknown column 't_account_trading.status' in 'order clause' - Invalid query: SELECT *, `t_account_trading`.`id` as `id`, `t_product`.`leverage` as `leverage`
FROM `t_account_trading`
JOIN `t_user` ON `t_user`.`id`=`t_account_trading`.`user_id`
JOIN `t_product` ON `t_product`.`id`=`t_account_trading`.`product_id`
ORDER BY `t_account_trading`.`status` ASC, `t_account_trading`.`id` DESC
 LIMIT 10
ERROR - 2021-07-31 15:54:03 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 15:55:05 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:05 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:05 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:05 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:05 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:05 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:05 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:05 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:06 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:06 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:06 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:06 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:40 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:40 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:48 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:48 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:49 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:49 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:49 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:49 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:49 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:49 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:50 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:51 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:51 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:51 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:51 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:51 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:51 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:51 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:55:51 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 15:59:33 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:59:37 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:59:40 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:59:41 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 15:59:52 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 16:00:47 --> Severity: Notice --> Undefined property: Account_trading::$point_member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 16:00:47 --> Severity: error --> Exception: Call to a member function get_data() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Account_trading.php 193
ERROR - 2021-07-31 16:04:46 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:04:54 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:04:56 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:05:06 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:05:07 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:20:47 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 16:23:45 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:23:47 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:23:52 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:23:53 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:24:05 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 16:24:10 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:31:20 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:31:22 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:31:58 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:31:59 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:32:07 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 09:32:13 --> Severity: Compile Error --> Cannot redeclare Withdrawal::_submit_upate() /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 211
ERROR - 2021-07-31 16:33:58 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 16:33:58 --> Severity: Notice --> Undefined property: Withdrawal::$member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 125
ERROR - 2021-07-31 16:33:58 --> Severity: error --> Exception: Call to a member function get_user() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 125
ERROR - 2021-07-31 16:34:07 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 16:34:07 --> Severity: Notice --> Undefined property: Withdrawal::$member_model /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 125
ERROR - 2021-07-31 16:34:07 --> Severity: error --> Exception: Call to a member function get_user() on null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 125
ERROR - 2021-07-31 16:35:43 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 16:36:05 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:36:08 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:36:09 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:36:20 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:36:21 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:36:36 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 16:39:11 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:39:14 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:39:21 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:39:22 --> Could not find the language line "referral_title"
ERROR - 2021-07-31 16:39:32 --> Could not find the language line "form_label_title"
ERROR - 2021-07-31 16:39:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 192
ERROR - 2021-07-31 16:39:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 198
ERROR - 2021-07-31 16:39:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 202
ERROR - 2021-07-31 16:39:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/controllers/l-admin/Withdrawal.php 203
ERROR - 2021-07-31 16:39:32 --> Query error: Column 'wallet_id' cannot be null - Invalid query: INSERT INTO `t_wallet_history` (`wallet_id`, `amount_before`, `amount`, `amount_after`, `source`, `withdraw_id`) VALUES (NULL, NULL, '100.0000', 100, 'Approval Withdrawal Member', 19)
ERROR - 2021-07-31 16:41:22 --> Could not find the language line "form_label_title"
