<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Rate';
$lang['mod_title_all'] = 'All Rate';
$lang['mod_title_add'] = 'Add New Rate';
$lang['mod_title_edit'] = 'Update Rate';
$lang['table_id'] = 'Id';
$lang['table_title'] = 'Type';
$lang['table_seotitle'] = 'Amount';
$lang['table_type'] = 'Type';
$lang['table_active'] = 'Last Update';
$lang['table_action'] = 'Action';
$lang['form_label_title'] = 'Amount';
$lang['form_message_add_success'] = 'Data Rate has been successfully added';
$lang['form_message_update_success'] = 'Data Rate has been successfully updated';
$lang['form_message_delete_success'] = 'Data Rate has been successfully deleted';