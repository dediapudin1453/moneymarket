<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 17:36:30 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\demoforex\application\config\routes.php 4
