<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Footer';
$lang['mod_title_all'] = 'Semua Footer';
$lang['mod_title_add'] = 'Tambah Footer';
$lang['mod_title_edit'] = 'Sunting Footer';
$lang['table_id'] = 'Id';
$lang['table_title'] = 'Jenis';
$lang['table_copyright'] = 'Copyright';
$lang['table_active'] = 'Aktif';
$lang['table_action'] = 'Action';
$lang['form_label_copyright'] = 'Copyright';
$lang['form_message_add_success'] = 'Data Footer telah berhasil ditambahkan';
$lang['form_message_update_success'] = 'Data Footer telah berhasil diperbarui';
$lang['form_message_delete_success'] = 'Data Footer telah berhasil dihapus';