<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-28 19:33:40 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
