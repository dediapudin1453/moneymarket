<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Halaman Depan';
$lang['mod_title_all'] = 'Semua Halaman Depan';
$lang['mod_title_add'] = 'Tambah Halaman Depan';
$lang['mod_title_edit'] = 'Sunting Halaman Depan';
$lang['table_id'] = 'Id';
$lang['table_section'] = 'Bagian';
$lang['table_content'] = 'Konten';
$lang['table_active'] = 'Aktif';
$lang['table_action'] = 'Aksi';
$lang['form_label_title'] = 'Bagian';
$lang['form_label_seotitle'] = 'Seotitle';
$lang['form_label_content'] = 'Konten';
$lang['form_label_picture'] = 'Gambar';
$lang['form_label_active'] = 'Aktif';
$lang['form_message_add_success'] = 'Data Halaman Depan telah berhasil ditambahkan';
$lang['form_message_update_success'] = 'Data Halaman Depan telah berhasil diperbarui';
$lang['form_message_delete_success'] = 'Data Halaman Depan telah berhasil dihapus';