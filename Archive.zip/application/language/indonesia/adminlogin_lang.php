<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['ci_admin'] = 'CiFireCMS Administrator';
$lang['login1'] = 'Masuk Ke Administrator';
$lang['login2'] = 'Lupa Kata Sandi';
$lang['or'] = 'ATAU';
$lang['login_title'] = 'Masuk';
$lang['login_username'] = 'Nama User';
$lang['login_email'] = 'Email';
$lang['login_pass'] = 'Kata Sandi';
$lang['login_forgot'] = 'Lupa kata sandi';
$lang['button_signin'] = 'Masuk';
$lang['button_back_to_login'] = 'Kembali ke panel masuk';
$lang['err_match'] = 'Password do not match';
$lang['err_required'] = 'tidak boleh kosong';
$lang['err_wrong'] = 'wrong';
$lang['err_mailnotexists'] = 'Email tidak ditemukan';
$lang['forgot_send'] = 'Kata sandi telah dikirim ke email Anda';