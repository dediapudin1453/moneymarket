<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-29 09:14:28 --> Could not find the language line "referral_title"
ERROR - 2021-03-29 09:14:44 --> Could not find the language line "referral_title"
ERROR - 2021-03-29 09:14:51 --> Could not find the language line "referral_title"
ERROR - 2021-03-29 09:15:08 --> Could not find the language line "referral_title"
ERROR - 2021-03-29 10:25:35 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting ',' or ';' /home/is0y6huka0a8/public_html/staging2/application/views/admin/index.php 63
ERROR - 2021-03-29 12:46:36 --> Severity: error --> Exception: syntax error, unexpected end of file /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 253
ERROR - 2021-03-29 12:46:43 --> Query error: Unknown column 'picture' in 'field list' - Invalid query: SELECT `id`, `username`, `join_date`, `picture`
FROM `t_user`
ORDER BY `join_date` DESC
 LIMIT 10
ERROR - 2021-03-29 13:07:07 --> Severity: Notice --> Array to string conversion /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 55
ERROR - 2021-03-29 13:12:04 --> Severity: error --> Exception: syntax error, unexpected end of file /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 251
ERROR - 2021-03-29 13:12:19 --> Severity: error --> Exception: syntax error, unexpected end of file /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 251
ERROR - 2021-03-29 13:12:21 --> Severity: error --> Exception: syntax error, unexpected end of file /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 251
ERROR - 2021-03-29 13:15:31 --> Query error: Unknown column 'amount_usd' in 'field list' - Invalid query: SELECT SUM(amount_usd) as amount
FROM `t_internal_transfer`
WHERE `status` = 'Approved'
ERROR - 2021-03-29 13:16:21 --> Severity: error --> Exception: syntax error, unexpected '<', expecting variable (T_VARIABLE) or '{' or '$' /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 85
ERROR - 2021-03-29 13:16:37 --> Severity: error --> Exception: syntax error, unexpected '<', expecting variable (T_VARIABLE) or '{' or '$' /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 85
ERROR - 2021-03-29 13:16:38 --> Severity: error --> Exception: syntax error, unexpected '<', expecting variable (T_VARIABLE) or '{' or '$' /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 85
ERROR - 2021-03-29 13:16:39 --> Severity: error --> Exception: syntax error, unexpected '<', expecting variable (T_VARIABLE) or '{' or '$' /home/is0y6huka0a8/public_html/application/views/mod/home/view_index.php 85
