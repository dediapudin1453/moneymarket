<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-25 07:51:43 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 07:51:45 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 07:51:46 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 08:29:59 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:31:02 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting ',' or ';' /home/is0y6huka0a8/public_html/staging2/application/views/member/account.php 327
ERROR - 2021-03-25 08:35:27 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:35:43 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:35:57 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:39:30 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:48:15 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:48:29 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:49:19 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:50:56 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:51:40 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 08:54:48 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 08:54:51 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 08:54:54 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 08:56:26 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 09:00:56 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:05:13 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:05:25 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:05:41 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:32:38 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 09:40:33 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 09:41:13 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 09:42:04 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:42:07 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:42:15 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:43:29 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:43:30 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:43:32 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:43:39 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:43:56 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:43:58 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:44:03 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 09:45:24 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:32:34 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:32:36 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:32:40 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:32:49 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:42:09 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:42:17 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:42:20 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:42:25 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:46:30 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:46:41 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:46:44 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:46:50 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:46:51 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:46:53 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:46:59 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 16:47:00 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 20:11:47 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 20:12:04 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 20:12:15 --> Could not find the language line "referral_title"
ERROR - 2021-03-25 20:12:55 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 20:24:45 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
ERROR - 2021-03-25 20:25:31 --> Severity: Notice --> Undefined variable: data /home/is0y6huka0a8/public_html/staging2/application/controllers/l-member/Account.php 475
