<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Homepage';
$lang['mod_title_all'] = 'All Homepage';
$lang['mod_title_add'] = 'Add New Homepage';
$lang['mod_title_edit'] = 'Update Homepage';
$lang['table_id'] = 'Id';
$lang['table_section'] = 'Section';
$lang['table_content'] = 'Content';
$lang['table_active'] = 'Active';
$lang['table_action'] = 'Action';
$lang['form_label_title'] = 'Name';
$lang['form_label_seotitle'] = 'Section';
$lang['form_label_content'] = 'Content';
$lang['form_label_picture'] = 'Picture';
$lang['form_label_active'] = 'Active';
$lang['form_message_add_success'] = 'Data Homepage has been successfully added';
$lang['form_message_update_success'] = 'Data Homepage has been successfully updated';
$lang['form_message_delete_success'] = 'Data Homepage has been successfully deleted';