<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-15 16:11:33 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
