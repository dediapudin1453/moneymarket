<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-20 10:08:24 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-11/application/views/mod/homepage/view_edit.php 35
