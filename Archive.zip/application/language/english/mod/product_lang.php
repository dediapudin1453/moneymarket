<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Account';
$lang['mod_title_all'] = 'All Account';
$lang['mod_title_add'] = 'Add New Account';
$lang['mod_title_edit'] = 'Update Account';
$lang['table_id'] = 'Id';
$lang['table_title'] = 'Account Type';
$lang['table_seotitle'] = 'Seotitle';
$lang['table_active'] = 'Active';
$lang['table_action'] = 'Action';
$lang['form_label_title'] = 'Title';
$lang['form_label_seotitle'] = 'Seotitle';
$lang['form_label_content'] = 'Content';
$lang['form_label_picture'] = 'Picture';
$lang['form_label_active'] = 'Active';
$lang['form_message_add_success'] = 'Data Account has been successfully added';
$lang['form_message_update_success'] = 'Data Account has been successfully updated';
$lang['form_message_delete_success'] = 'Data Account has been successfully deleted';