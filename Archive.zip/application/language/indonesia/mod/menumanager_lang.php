<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Manajemen Menu';