<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-23 22:54:04 --> Query error: Table 'wallwadefx.t_step_register' doesn't exist - Invalid query: SELECT *
FROM `t_step_register`
ERROR - 2021-03-23 22:54:26 --> Query error: Table 'wallwadefx.t_step_register' doesn't exist - Invalid query: SELECT *
FROM `t_step_register`
ERROR - 2021-03-23 22:54:31 --> Query error: Table 'wallwadefx.t_step_register' doesn't exist - Invalid query: SELECT *
FROM `t_step_register`
ERROR - 2021-03-23 22:55:00 --> Query error: Table 'wallwadefx.t_step_register' doesn't exist - Invalid query: SELECT *
FROM `t_step_register`
ERROR - 2021-03-23 22:55:21 --> Query error: Table 'wallwadefx.t_step_register' doesn't exist - Invalid query: SELECT *
FROM `t_step_register`
ERROR - 2021-03-23 22:55:26 --> Query error: Table 'wallwadefx.t_step_register' doesn't exist - Invalid query: SELECT *
FROM `t_step_register`
