<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-08 02:28:07 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-08 02:28:11 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-08 02:28:16 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-08 09:26:58 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-08 09:27:07 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-08 09:27:38 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-08 09:27:55 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-08 09:28:07 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-08 09:28:43 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
