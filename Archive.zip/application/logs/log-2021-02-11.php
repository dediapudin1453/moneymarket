<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-11 10:57:59 --> Could not find the language line "login_name"
ERROR - 2021-02-11 10:57:59 --> Could not find the language line "login_email"
ERROR - 2021-02-11 10:57:59 --> Could not find the language line "login_pass"
ERROR - 2021-02-11 10:57:59 --> Could not find the language line "login_pass2"
ERROR - 2021-02-11 10:57:59 --> Could not find the language line "err_match"
ERROR - 2021-02-11 10:57:59 --> Could not find the language line "form_validation__cek_username_register"
ERROR - 2021-02-11 10:57:59 --> Could not find the language line "form_validation__cek_reg_email"
ERROR - 2021-02-11 11:01:09 --> Could not find the language line "login_name"
ERROR - 2021-02-11 11:01:09 --> Could not find the language line "login_email"
ERROR - 2021-02-11 11:01:09 --> Could not find the language line "login_pass"
ERROR - 2021-02-11 11:01:09 --> Could not find the language line "login_pass2"
ERROR - 2021-02-11 11:01:09 --> Could not find the language line "err_match"
ERROR - 2021-02-11 11:01:09 --> Could not find the language line "form_validation__cek_username_register"
ERROR - 2021-02-11 11:01:09 --> Could not find the language line "form_validation__cek_reg_email"
ERROR - 2021-02-11 11:15:38 --> Could not find the language line "login_name"
ERROR - 2021-02-11 11:15:38 --> Could not find the language line "login_email"
ERROR - 2021-02-11 11:15:38 --> Could not find the language line "login_pass"
ERROR - 2021-02-11 11:15:38 --> Could not find the language line "login_pass2"
ERROR - 2021-02-11 11:15:38 --> Could not find the language line "err_match"
ERROR - 2021-02-11 11:15:38 --> Could not find the language line "form_validation__cek_username_register"
ERROR - 2021-02-11 11:15:38 --> Could not find the language line "form_validation__cek_reg_email"
ERROR - 2021-02-11 11:16:55 --> Could not find the language line "login_name"
ERROR - 2021-02-11 11:16:55 --> Could not find the language line "login_email"
ERROR - 2021-02-11 11:16:55 --> Could not find the language line "login_pass"
ERROR - 2021-02-11 11:16:55 --> Could not find the language line "login_pass2"
ERROR - 2021-02-11 11:16:55 --> Could not find the language line "err_match"
ERROR - 2021-02-11 11:16:55 --> Could not find the language line "err_mailexists"
ERROR - 2021-02-11 11:17:54 --> Could not find the language line "login_name"
ERROR - 2021-02-11 11:17:54 --> Could not find the language line "login_email"
ERROR - 2021-02-11 11:17:54 --> Could not find the language line "login_pass"
ERROR - 2021-02-11 11:17:54 --> Could not find the language line "login_pass2"
ERROR - 2021-02-11 11:17:54 --> Could not find the language line "err_match"
ERROR - 2021-02-11 11:17:57 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\libraries\Email.php 1902
ERROR - 2021-02-11 11:53:43 --> Severity: error --> Exception: Call to undefined function conten_url() C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 33
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:22:09 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 105
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: url C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:25:14 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 106
ERROR - 2021-02-11 12:28:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\l-member\Login.php 425
ERROR - 2021-02-11 12:38:43 --> Severity: Notice --> Undefined index: log_member C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\helpers\function_helper.php 978
ERROR - 2021-02-11 12:38:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\helpers\function_helper.php 978
ERROR - 2021-02-11 12:38:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\helpers\function_helper.php 980
ERROR - 2021-02-11 08:34:31 --> Severity: error --> Exception: syntax error, unexpected '(' C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 338
ERROR - 2021-02-11 08:34:32 --> Severity: error --> Exception: syntax error, unexpected '(' C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 338
ERROR - 2021-02-11 14:49:15 --> Severity: Notice --> Undefined property: Home::$home C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 57
ERROR - 2021-02-11 14:49:15 --> Severity: error --> Exception: Call to a member function getPrice() on null C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 57
ERROR - 2021-02-11 14:49:17 --> Severity: Notice --> Undefined property: Home::$home C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 57
ERROR - 2021-02-11 14:49:17 --> Severity: error --> Exception: Call to a member function getPrice() on null C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\header.php 57
ERROR - 2021-02-11 15:41:18 --> Severity: error --> Exception: Cannot use [] for reading C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 391
ERROR - 2021-02-11 15:41:33 --> Severity: error --> Exception: Cannot use [] for reading C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 392
ERROR - 2021-02-11 15:41:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\database\DB_driver.php 1471
ERROR - 2021-02-11 15:41:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `t_running_price` (0) VALUES (Array)
ERROR - 2021-02-11 15:42:04 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\database\DB_driver.php 1471
ERROR - 2021-02-11 15:42:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `t_running_price` (0) VALUES (Array)
ERROR - 2021-02-11 15:42:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\database\DB_driver.php 1471
ERROR - 2021-02-11 15:42:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `t_running_price` (0) VALUES (Array)
ERROR - 2021-02-11 15:42:35 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\database\DB_driver.php 1471
ERROR - 2021-02-11 15:42:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `t_running_price` (0) VALUES (Array)
ERROR - 2021-02-11 15:42:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\database\DB_driver.php 1471
ERROR - 2021-02-11 15:42:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `t_running_price` (0) VALUES (Array)
ERROR - 2021-02-11 15:43:30 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\database\DB_driver.php 1471
ERROR - 2021-02-11 15:43:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `t_running_price_satu` (0) VALUES (Array)
ERROR - 2021-02-11 15:45:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\database\DB_driver.php 1471
ERROR - 2021-02-11 15:45:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES (Array)' at line 1 - Invalid query: INSERT INTO `t_running_price_satu` (0) VALUES (Array)
ERROR - 2021-02-11 10:04:06 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 424
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 345
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 346
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: mata_uang C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 348
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 345
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 346
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: mata_uang C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 348
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 345
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 346
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: mata_uang C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 348
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 345
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 346
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: mata_uang C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 348
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 345
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 346
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: mata_uang C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 348
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 345
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 346
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: mata_uang C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 348
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 345
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 346
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: mata_uang C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 348
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 345
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: date C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 346
ERROR - 2021-02-11 16:04:25 --> Severity: Notice --> Undefined index: mata_uang C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\Home.php 348
