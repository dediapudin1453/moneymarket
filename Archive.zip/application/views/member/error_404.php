<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="content d-flex justify-content-center align-items-center">
	<div class="flex-fill">
		<div class="text-center mb-3">
			<h1 class="error-title">404</h1>
			<h3>Oops, an error has occurred. Page not found!</h3>
		</div>
	</div>
</div>