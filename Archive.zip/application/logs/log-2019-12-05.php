<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-05 09:28:16 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-7/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-05 09:42:32 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-7/application/views/mod/homepage/view_edit.php 35
