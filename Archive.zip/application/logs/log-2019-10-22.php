<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-22 16:59:50 --> 404 Page Not Found: 
ERROR - 2019-10-22 22:35:03 --> 404 Page Not Found: 
ERROR - 2019-10-22 22:51:37 --> Severity: error --> Exception: Call to undefined method Menu::front_menu() C:\xampp\htdocs\cifirecms\application\core\Web_Controller.php 73
