<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-12 09:47:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 09:47:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 09:52:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 09:52:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 09:52:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 09:52:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 09:52:55 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 09:52:55 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 10:07:00 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 67
ERROR - 2020-05-12 10:08:07 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 67
ERROR - 2020-05-12 10:08:41 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.secureserver.net:587 (Connection timed out) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:08:41 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 67
ERROR - 2020-05-12 10:08:57 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.secureserver.net:587 (Connection timed out) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:08:57 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 67
ERROR - 2020-05-12 10:10:22 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.secureserver.net:587 (Connection timed out) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:10:22 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 64
ERROR - 2020-05-12 10:10:59 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.secureserver.net:587 (Connection timed out) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:14:39 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:587 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:14:45 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:587 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:14:49 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:587 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:17:15 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:3535 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:17:31 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:25 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:17:48 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:465 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:18:04 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:587 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:18:52 --> Severity: error --> Exception: Call to undefined method CI_Email::false() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 64
ERROR - 2020-05-12 10:19:07 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 65
ERROR - 2020-05-12 10:19:36 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 65
ERROR - 2020-05-12 10:21:40 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:3535 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:08 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:08 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:25 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:14 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:14 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:25 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:24 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:24 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:465 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:27 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:27 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:465 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:37 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:37 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:39 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:39 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:53 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:53 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:80 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:57 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:22:57 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:80 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:25:21 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:25:21 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:80 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:26:13 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-12 10:26:13 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-12 10:26:13 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-12 10:26:13 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-12 10:27:26 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:27:26 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:80 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:29:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 10:29:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 10:29:55 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-12 10:29:55 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-12 10:29:55 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-12 10:29:55 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-12 10:30:03 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:30:03 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:25 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:30:59 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:30:59 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:35:44 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:35:44 --> Severity: Warning --> fsockopen(): unable to connect to mail@rexchangermarkets.com:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:36:12 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:587 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 10:38:29 --> Severity: Warning --> fsockopen(): unable to connect to smtpout.asia.secureserver.net:3535 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-12 11:34:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 11:35:00 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 11:35:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 11:35:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 11:35:15 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 11:35:15 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 11:44:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 11:44:18 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 11:44:18 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 11:44:18 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 11:44:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 11:44:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 11:44:37 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 11:44:37 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 04:47:36 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 168
ERROR - 2020-05-12 11:47:49 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_result::order_by() /home/qx59rn1k06vg/public_html/application/models/member/Account_model.php 28
ERROR - 2020-05-12 11:48:23 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_result::order_by() /home/qx59rn1k06vg/public_html/application/models/member/Account_model.php 28
ERROR - 2020-05-12 11:48:38 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::orderby() /home/qx59rn1k06vg/public_html/application/models/member/Account_model.php 27
ERROR - 2020-05-12 11:51:41 --> Severity: Notice --> Undefined property: Account::$upload /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 411
ERROR - 2020-05-12 11:51:41 --> Severity: error --> Exception: Call to a member function initialize() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 411
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: referral_username /home/qx59rn1k06vg/public_html/application/views/member/account.php 60
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: religion /home/qx59rn1k06vg/public_html/application/views/member/account.php 109
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: religion /home/qx59rn1k06vg/public_html/application/views/member/account.php 112
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: religion /home/qx59rn1k06vg/public_html/application/views/member/account.php 115
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: religion /home/qx59rn1k06vg/public_html/application/views/member/account.php 118
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: religion /home/qx59rn1k06vg/public_html/application/views/member/account.php 121
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: religion /home/qx59rn1k06vg/public_html/application/views/member/account.php 124
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: birthplace /home/qx59rn1k06vg/public_html/application/views/member/account.php 137
ERROR - 2020-05-12 12:21:32 --> Severity: Notice --> Undefined index: no_ktp /home/qx59rn1k06vg/public_html/application/views/member/account.php 159
ERROR - 2020-05-12 13:16:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:16:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:16:41 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:16:41 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:16:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:16:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:16:55 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:16:55 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:17:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:17:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:17:28 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:17:28 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:17:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:17:35 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:17:35 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:17:35 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:17:35 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:17:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:17:36 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:17:36 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:18:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:18:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:18:12 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:18:12 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:18:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:18:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:18:13 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:18:13 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-12 13:18:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:21:10 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:21:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:22:08 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:22:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:22:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:22:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:27:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:30:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:30:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:31:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:34:22 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:35:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:36:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:37:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:37:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:38:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:40:16 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:40:45 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:40:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:44:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:44:30 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:44:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:44:35 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:45:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 13:45:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:19:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:19:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:21:08 --> Severity: Notice --> Undefined property: Account::$upload /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 558
ERROR - 2020-05-12 14:21:08 --> Severity: error --> Exception: Call to a member function initialize() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 558
ERROR - 2020-05-12 14:21:35 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 572
ERROR - 2020-05-12 14:21:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:21:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:21:56 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 572
ERROR - 2020-05-12 14:22:47 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 572
ERROR - 2020-05-12 14:23:01 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 572
ERROR - 2020-05-12 14:23:16 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 572
ERROR - 2020-05-12 14:29:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:30:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:30:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:30:12 --> Severity: Notice --> Undefined property: Withdrawal::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Withdrawal.php 29
ERROR - 2020-05-12 14:30:12 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Withdrawal.php 29
ERROR - 2020-05-12 14:42:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:42:45 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:43:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:45:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:50:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:50:50 --> 404 Page Not Found: 
ERROR - 2020-05-12 14:50:53 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:50:53 --> 404 Page Not Found: 
ERROR - 2020-05-12 14:50:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:50:56 --> 404 Page Not Found: 
ERROR - 2020-05-12 14:51:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:51:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:53:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:54:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:54:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:54:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:54:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:54:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:54:44 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:54:44 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:56:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:56:42 --> 404 Page Not Found: 
ERROR - 2020-05-12 14:56:48 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:56:48 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:56:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:56:49 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:56:49 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:57:19 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:57:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:57:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:57:23 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:57:23 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:57:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:57:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:57:41 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:57:41 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:58:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:58:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:58:41 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:58:41 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:59:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:59:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:59:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:59:40 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:59:40 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:59:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:59:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 14:59:55 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 14:59:55 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 15:00:07 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 573
ERROR - 2020-05-12 15:04:25 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 573
ERROR - 2020-05-12 15:08:30 --> Severity: error --> Exception: Argument 1 passed to Account_model::update_profile() must be of the type array, string given, called in /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php on line 236 /home/qx59rn1k06vg/public_html/application/models/member/Account_model.php 34
ERROR - 2020-05-12 15:09:36 --> The upload path does not appear to be valid.
ERROR - 2020-05-12 15:10:14 --> The upload path does not appear to be valid.
ERROR - 2020-05-12 15:12:18 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 475
ERROR - 2020-05-12 15:12:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:12:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:12:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:13:19 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:13:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:13:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:13:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:13:23 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 15:13:23 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 15:13:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:13:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:13:28 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 15:13:28 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 15:13:31 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:14:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:14:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:14:08 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:35:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 15:53:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 16:15:02 --> Severity: error --> Exception: /home/qx59rn1k06vg/public_html/application/models/mod/Rate_model.php exists, but doesn't declare class Rate_model /home/qx59rn1k06vg/public_html/system/core/Loader.php 340
ERROR - 2020-05-12 16:25:43 --> Severity: Notice --> Undefined index: title /home/qx59rn1k06vg/public_html/application/views/mod/rate/view_edit.php 34
ERROR - 2020-05-12 16:25:43 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/rate/view_edit.php 35
ERROR - 2020-05-12 16:25:43 --> Severity: Notice --> Undefined index: subtitle /home/qx59rn1k06vg/public_html/application/views/mod/rate/view_edit.php 38
ERROR - 2020-05-12 16:25:43 --> Severity: Notice --> Undefined index: content /home/qx59rn1k06vg/public_html/application/views/mod/rate/view_edit.php 50
ERROR - 2020-05-12 16:25:43 --> Severity: Notice --> Undefined index: content /home/qx59rn1k06vg/public_html/application/views/mod/rate/view_edit.php 54
ERROR - 2020-05-12 16:25:43 --> Severity: Notice --> Undefined index: active /home/qx59rn1k06vg/public_html/application/views/mod/rate/view_edit.php 70
ERROR - 2020-05-12 16:25:43 --> Severity: Notice --> Undefined index: picture /home/qx59rn1k06vg/public_html/application/views/mod/rate/view_edit.php 96
ERROR - 2020-05-12 16:48:54 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_rate`
WHERE `seotitle` = ''
ERROR - 2020-05-12 16:56:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 16:58:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 17:02:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 18:36:18 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 18:36:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 18:36:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 18:37:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 18:40:08 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:13:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:13:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:13:31 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:13:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:13:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:13:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:13:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:13:44 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 20:13:44 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 20:21:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:21:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:21:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:28:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:28:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:28:38 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 20:28:38 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 20:29:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:30:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:30:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:30:46 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:38:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:38:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:45:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:45:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:45:58 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 20:45:58 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 20:45:58 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 21:01:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:02:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:12:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:12:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:12:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:13:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:13:57 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:18:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:19:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:21:10 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:21:30 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:22:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:24:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:24:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:25:45 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:27:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:27:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:29:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:30:31 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:31:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:31:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:32:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 21:32:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 23:14:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 23:14:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 23:15:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 23:15:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 23:15:02 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 23:15:02 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-12 23:15:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 23:15:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-12 23:15:14 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-12 23:15:14 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
