<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-24 16:43:26 --> Could not find the language line "table_content"
ERROR - 2020-04-24 16:43:29 --> Could not find the language line "form_label_content"
ERROR - 2020-04-24 16:43:29 --> Severity: Notice --> Undefined index: content /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 46
ERROR - 2020-04-24 16:43:29 --> Severity: Notice --> Undefined index: active /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 63
ERROR - 2020-04-24 16:43:29 --> Could not find the language line "form_label_active"
ERROR - 2020-04-24 16:43:29 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-24 16:43:29 --> Severity: Notice --> Undefined index: picture /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 89
ERROR - 2020-04-24 16:43:29 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-24 16:43:31 --> Could not find the language line "table_content"
