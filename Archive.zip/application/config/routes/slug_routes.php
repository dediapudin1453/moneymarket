<?php defined('BASEPATH') OR exit('No direct script access allowed');
$route['detailpost/([a-z0-9-]+)'] = 'post/index/$1';