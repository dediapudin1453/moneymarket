<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Pesan';
$lang['mod_title_detail'] = 'Detail';
$lang['mod_title_reply'] = 'Balas Pesan';
$lang['mod_title_read'] = 'Detail';
$lang['inbox'] = 'Kotak Masuk';
$lang['send_box'] = 'Terkirim';
$lang['table_from'] = 'Nama | Email';
$lang['table_subject'] = 'Subyek';
$lang['table_date'] = 'Tanggal';
$lang['table_action'] = 'Aksi';
$lang['form_label_to'] = 'Untuk';
$lang['form_label_subject'] = 'Subyek';
$lang['form_label_message'] = 'Pesan';
$lang['button_send'] = 'Kirim';
$lang['button_reply'] = 'Balas';
$lang['dialog_delete_mail_content'] = 'Anda yakin ingin menghapus email ini?';
$lang['message_delete_success'] = 'Data telah berhasil dihapus';