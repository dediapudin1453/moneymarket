<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-18 12:38:09 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 12:38:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:40:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:40:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:41:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:41:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:42:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:42:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:42:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:42:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:42:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:42:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:43:10 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 15:47:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 16:06:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Deposit_model /home/qx59rn1k06vg/public_html/system/core/Loader.php 348
ERROR - 2020-05-18 16:06:30 --> Severity: Notice --> Undefined property: Home::$key /home/qx59rn1k06vg/public_html/system/core/Model.php 73
ERROR - 2020-05-18 16:06:30 --> Query error: FUNCTION mydbbrokers.SUM does not exist. Check the 'Function Name Parsing and Resolution' section in the Reference Manual - Invalid query: SELECT SUM (amount_usd) as amount
FROM `t_deposit`
WHERE `user_id` IS NULL
AND `status` = 'Approved'
ERROR - 2020-05-18 16:06:40 --> Query error: FUNCTION mydbbrokers.SUM does not exist. Check the 'Function Name Parsing and Resolution' section in the Reference Manual - Invalid query: SELECT SUM (amount_usd) as amount
FROM `t_deposit`
WHERE `user_id` = '10'
AND `status` = 'Approved'
ERROR - 2020-05-18 16:07:06 --> Query error: FUNCTION mydbbrokers.SUM does not exist. Check the 'Function Name Parsing and Resolution' section in the Reference Manual - Invalid query: SELECT SUM (amount_usd) as amount
FROM `t_withdraw`
WHERE `user_id` = '10'
AND `status` = 'Approved'
ERROR - 2020-05-18 16:07:46 --> Query error: FUNCTION mydbbrokers.COUNT does not exist. Check the 'Function Name Parsing and Resolution' section in the Reference Manual - Invalid query: SELECT COUNT (id) as jml
FROM `t_account_trading`
WHERE `user_id` = '10'
AND `status` = 'Approved'
ERROR - 2020-05-18 16:07:57 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT COUNT(id) as jml
FROM `t_account_trading`
WHERE `user_id` = '10'
AND `status` = 'Approved'
ERROR - 2020-05-18 18:12:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 20:11:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 22:11:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 22:11:12 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-05-18 22:11:12 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-05-18 22:11:12 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-05-18 22:11:18 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 22:11:18 --> Could not find the language line "referral_title"
ERROR - 2020-05-18 22:11:43 --> Could not find the language line "referral_title"
