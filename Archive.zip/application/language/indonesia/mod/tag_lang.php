<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Tag';
$lang['mod_title_all'] = 'Semua Tag';
$lang['mod_title_add'] = 'Tambah Baru';
$lang['mod_lang_1'] = 'Pisahkan dengan tanda ( , )';
$lang['table_id'] = 'Id';
$lang['table_title'] = 'Judul';
$lang['table_count'] = 'Jumlah';
$lang['table_action'] = 'Aksi';
$lang['form_label_tag'] = 'Tag';
$lang['dialog_add_title'] = 'Tambah Tag';
$lang['form_message_add_success'] = 'Tag telah berhasil ditambahkan';
$lang['form_message_update_success'] = 'Tag telah berhasil diperbarui';
$lang['form_message_delete_success'] = 'Tag telah berhasil dihapus';