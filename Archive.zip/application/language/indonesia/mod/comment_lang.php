<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_lang_1'] = 'Komentar';
$lang['mod_title'] = 'Komentar';
$lang['mod_title_all'] = 'Semua Komentar';
$lang['table_name'] = 'Nama';
$lang['table_comment'] = 'Komentar | Post';
$lang['table_date'] = 'Tanggal';
$lang['table_action'] = 'Aksi';
$lang['button_block'] = 'Blokir';
$lang['button_unblock'] = 'Buka Blokir';
$lang['form_message_delete_success'] = 'Komentar telah berhasil dihapus';
$lang['dialog_block_title'] = 'Blokir Komentar';
$lang['dialog_block_content'] = 'Anda yakin ingin memblokir komentar ini ?';
$lang['dialog_active_title'] = 'Aktifkan Komentar';
$lang['dialog_active_content'] = 'Anda yakin ingin mengaktifkan komentar ini ?';