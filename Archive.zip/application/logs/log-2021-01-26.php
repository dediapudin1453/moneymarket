<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-26 12:31:45 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:31:51 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:32:15 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:33:36 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:33:38 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:33:56 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:34:39 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:34:46 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:35:16 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:37:12 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:37:14 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:37:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:47:59 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:48:52 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:49:23 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:49:23 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:49:45 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 12:49:59 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:50:21 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 12:52:14 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:02:26 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:03:04 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:03:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:03:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:04:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:04:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:10:58 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:10:59 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:11:38 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:11:38 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:12:11 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:12:11 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:12:42 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:12:50 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:12:56 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:12:56 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:10 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:10 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:13 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:34 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:13:38 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:41 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:56 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:56 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:13:59 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:14:10 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:14:14 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:16:41 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:18:34 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:19:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:19:29 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:19:43 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:19:43 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:19:45 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:19:46 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:19:56 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:20:00 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:21:04 --> Severity: Notice --> Uninitialized string offset: 3 /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2316
ERROR - 2021-01-26 13:21:04 --> Severity: Notice --> Uninitialized string offset: 3 /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2316
ERROR - 2021-01-26 13:21:04 --> Severity: Notice --> Uninitialized string offset: 3 /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2316
ERROR - 2021-01-26 13:21:04 --> Severity: Notice --> Uninitialized string offset: 3 /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2316
ERROR - 2021-01-26 13:21:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:21:39 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:22:36 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:23:31 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:23:39 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:23:55 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:24:00 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:24:00 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:25:05 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:25:08 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:25:24 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:25:31 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:25:31 --> Severity: Notice --> Undefined variable: response /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Internal_transfer.php 409
ERROR - 2021-01-26 13:25:41 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:25:55 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:26:58 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:26:58 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:26:59 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:26:59 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:26:59 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:26:59 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:00 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:00 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:00 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:01 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:01 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:01 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:01 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:02 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:02 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:02 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:02 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:03 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:03 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:03 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:03 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:04 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:27:08 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:27:08 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:27:16 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:27:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:27:52 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:27:52 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:28:04 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:29:39 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:29:50 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:30:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:30:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:30:51 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:33:17 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:33:23 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:33:28 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:587 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:33:30 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:33:30 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:33:42 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:33:46 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:33:47 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:465 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:34:04 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:34:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:34:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 13:34:38 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 13:35:53 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:465 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:35:57 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:465 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:36:41 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:465 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:37:59 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:465 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:38:07 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:465 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:38:41 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:465 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:39:11 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail.com:465 (Connection refused) /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2069
ERROR - 2021-01-26 13:40:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:57 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:57 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:57 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:57 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:58 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:58 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:58 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:58 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:59 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:59 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:59 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:40:59 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:00 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:00 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:00 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:00 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:01 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:01 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:01 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:01 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:41:02 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 13:42:42 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/kqw5yzwxdlcw/public_html/application/controllers/Test.php 70
ERROR - 2021-01-26 13:42:49 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/kqw5yzwxdlcw/public_html/application/controllers/Test.php 70
ERROR - 2021-01-26 13:45:12 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/kqw5yzwxdlcw/public_html/application/controllers/Test.php 70
ERROR - 2021-01-26 13:46:34 --> Severity: error --> Exception: Call to undefined method CI_Email::printDebugger() /home/kqw5yzwxdlcw/public_html/application/controllers/Test.php 70
ERROR - 2021-01-26 14:31:51 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:51 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:52 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:52 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:52 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:52 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:53 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:53 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:53 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:53 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:54 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:54 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:54 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:54 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:55 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:56 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:31:57 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:29 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:30 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:30 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:30 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:30 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:31 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:31 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:31 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:31 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:32 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:33 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:34 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:32:35 --> Severity: Notice --> fwrite(): send of 6 bytes failed with errno=32 Broken pipe /home/kqw5yzwxdlcw/public_html/system/libraries/Email.php 2268
ERROR - 2021-01-26 14:45:52 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 14:48:45 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 14:48:47 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:20:28 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:20:30 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:21:00 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:21:00 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:22:05 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:22:06 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:23:53 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:23:54 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:24:07 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:24:07 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:24:34 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:28:55 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:29:16 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 15:29:17 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 17:26:31 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 17:26:33 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 17:26:39 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 17:26:51 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 17:26:57 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 17:26:57 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 17:28:26 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 17:52:29 --> Severity: Notice --> Undefined property: Login::$email /home/kqw5yzwxdlcw/public_html/application/controllers/l-member/Login.php 481
ERROR - 2021-01-26 17:52:29 --> Severity: error --> Exception: Call to a member function initialize() on null /home/kqw5yzwxdlcw/public_html/application/controllers/l-member/Login.php 481
ERROR - 2021-01-26 19:57:57 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/application/controllers/l-member/Account.php 475
ERROR - 2021-01-26 20:02:06 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:02:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:03:50 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:05:16 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:05:17 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:06:25 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:06:55 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:07:11 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:07:19 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:07:19 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/application/views/member/account_trading.php 130
ERROR - 2021-01-26 20:07:19 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/application/views/member/account_trading.php 141
ERROR - 2021-01-26 20:07:19 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/application/views/member/account_trading.php 147
ERROR - 2021-01-26 20:07:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:07:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:07:43 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:07:43 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:07:48 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:07:48 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:10:20 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:11:41 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:11:57 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:13:23 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:15:23 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:15:28 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:15:51 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:15:52 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:17:33 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:18:16 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:18:57 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:18:57 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:19:08 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:19:09 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:19:25 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:19:51 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:20:10 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:20:48 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:20:50 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:21:00 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:21:12 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:21:12 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:21:17 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:21:45 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:22:02 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:22:41 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:22:55 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:22:55 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:23:04 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:23:17 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:23:22 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:23:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:23:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:23:47 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:23:55 --> Could not find the language line "form_label_title"
ERROR - 2021-01-26 20:24:36 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:24:49 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:25:13 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:25:14 --> Could not find the language line "referral_title"
ERROR - 2021-01-26 20:25:41 --> Could not find the language line "form_label_title"
