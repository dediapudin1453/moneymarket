<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-09 14:37:20 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-14/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-09 14:56:55 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-14/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-09 15:12:43 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-14/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-09 15:24:55 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-14/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-09 15:48:18 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-14/application/views/mod/homepage/view_edit.php 35
