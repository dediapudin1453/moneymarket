<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-17 15:19:39 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:20:18 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:20:31 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:24:32 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:25:06 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:25:52 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:48:14 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:49:24 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:49:44 --> Could not find the language line "table_content"
ERROR - 2019-11-17 15:52:14 --> Could not find the language line "table_content"
ERROR - 2019-11-17 20:04:22 --> Could not find the language line "table_content"
ERROR - 2019-11-17 20:04:35 --> Could not find the language line "form_label_content"
ERROR - 2019-11-17 20:04:35 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-17 20:04:35 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-17 20:04:35 --> Could not find the language line "form_label_active"
ERROR - 2019-11-17 20:04:35 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:35 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-17 20:04:35 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:39 --> Could not find the language line "form_label_content"
ERROR - 2019-11-17 20:04:39 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-17 20:04:39 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-17 20:04:39 --> Could not find the language line "form_label_active"
ERROR - 2019-11-17 20:04:39 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:39 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-17 20:04:39 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:43 --> Could not find the language line "form_label_content"
ERROR - 2019-11-17 20:04:43 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-17 20:04:43 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-17 20:04:43 --> Could not find the language line "form_label_active"
ERROR - 2019-11-17 20:04:43 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:43 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-17 20:04:43 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:45 --> Could not find the language line "table_content"
ERROR - 2019-11-17 20:04:48 --> Could not find the language line "form_label_content"
ERROR - 2019-11-17 20:04:48 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-17 20:04:48 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-17 20:04:48 --> Could not find the language line "form_label_active"
ERROR - 2019-11-17 20:04:48 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:48 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-17 20:04:48 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:53 --> Could not find the language line "form_label_content"
ERROR - 2019-11-17 20:04:53 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-17 20:04:53 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-17 20:04:53 --> Could not find the language line "form_label_active"
ERROR - 2019-11-17 20:04:53 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:53 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-17 20:04:53 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:59 --> Could not find the language line "form_label_content"
ERROR - 2019-11-17 20:04:59 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-17 20:04:59 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-17 20:04:59 --> Could not find the language line "form_label_active"
ERROR - 2019-11-17 20:04:59 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:04:59 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-17 20:04:59 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:05:15 --> Could not find the language line "form_label_content"
ERROR - 2019-11-17 20:05:15 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-17 20:05:15 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-17 20:05:15 --> Could not find the language line "form_label_active"
ERROR - 2019-11-17 20:05:15 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:05:15 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-17 20:05:15 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:05:18 --> Could not find the language line "table_content"
ERROR - 2019-11-17 20:05:56 --> Could not find the language line "form_label_content"
ERROR - 2019-11-17 20:05:56 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-17 20:05:56 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-17 20:05:56 --> Could not find the language line "form_label_active"
ERROR - 2019-11-17 20:05:56 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:05:56 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-17 20:05:56 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-17 20:06:24 --> Could not find the language line "table_content"
