<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-16 09:27:20 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\linggafx\application\core\Web_Controller.php 45
ERROR - 2021-04-16 09:44:01 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\linggafx\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-04-16 09:44:01 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-04-16 09:44:01 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-04-16 09:44:01 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\linggafx\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-04-16 09:44:01 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-04-16 09:44:01 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
