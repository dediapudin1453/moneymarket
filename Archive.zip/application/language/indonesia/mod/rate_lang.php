<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Rate';
$lang['mod_title_all'] = 'Semua Rate';
$lang['mod_title_add'] = 'Tambah Rate';
$lang['mod_title_edit'] = 'Sunting Rate';
$lang['table_id'] = 'Id';
$lang['table_title'] = 'Jenis';
$lang['table_seotitle'] = 'Jumlah';
$lang['table_active'] = 'Perubahan Terakhir';
$lang['table_type'] = 'Tipe';
$lang['table_action'] = 'Aksi';
$lang['form_label_title'] = 'Jumlah';
$lang['form_message_add_success'] = 'Data Rate telah berhasil ditambahkan';
$lang['form_message_update_success'] = 'Data Rate telah berhasil diperbarui';
$lang['form_message_delete_success'] = 'Data Rate telah berhasil dihapus';