<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-27 06:47:59 --> Could not find the language line "referral_title"
ERROR - 2020-06-27 06:48:05 --> Could not find the language line "referral_title"
ERROR - 2020-06-27 06:48:11 --> Could not find the language line "referral_title"
ERROR - 2020-06-27 06:48:13 --> Could not find the language line "referral_title"
ERROR - 2020-06-27 07:08:58 --> Could not find the language line "referral_title"
ERROR - 2020-06-27 08:46:13 --> Could not find the language line "referral_title"
ERROR - 2020-06-27 08:46:57 --> Could not find the language line "referral_title"
ERROR - 2020-06-27 09:20:28 --> Could not find the language line "referral_title"
ERROR - 2020-06-27 19:55:16 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-27 19:55:22 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-06-27 19:55:24 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
