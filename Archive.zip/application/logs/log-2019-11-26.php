<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-26 01:42:45 --> Severity: error --> Exception: syntax error, unexpected '.' /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Product.php 37
ERROR - 2019-11-26 01:44:33 --> Severity: error --> Exception: syntax error, unexpected ';' /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Product.php 37
ERROR - 2019-11-26 09:54:44 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-26 09:55:18 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-26 20:12:44 --> Query error: Unknown column 'group_id' in 'where clause' - Invalid query: SELECT *
FROM `t_menu_group`
WHERE `group_id` = 4
ERROR - 2019-11-26 20:13:41 --> Query error: Unknown column 'group_id' in 'where clause' - Invalid query: SELECT *
FROM `t_menu_group`
WHERE `group_id` = 4
ERROR - 2019-11-26 20:13:51 --> Query error: Unknown column 'group_id' in 'where clause' - Invalid query: SELECT *
FROM `t_menu_group`
WHERE `group_id` = 4
ERROR - 2019-11-26 20:32:46 --> Query error: Table 'u7014999_websitepraktis.t_menuwebsite' doesn't exist - Invalid query: SELECT *
FROM `t_menuwebsite`
WHERE `group_id` = '4'
ORDER BY `id` DESC
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:00 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:14 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:17 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:33:20 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 35
ERROR - 2019-11-26 20:37:04 --> Severity: Notice --> Undefined index: clas /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 45
ERROR - 2019-11-26 20:37:04 --> Severity: Notice --> Undefined index: clas /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 45
ERROR - 2019-11-26 20:37:04 --> Severity: Notice --> Undefined index: clas /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 45
ERROR - 2019-11-26 20:37:05 --> Severity: Notice --> Undefined index: clas /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 45
ERROR - 2019-11-26 20:37:05 --> Severity: Notice --> Undefined index: clas /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 45
ERROR - 2019-11-26 20:40:55 --> Could not find the language line "form_label_content"
ERROR - 2019-11-26 20:40:55 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-26 20:40:55 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-26 20:49:56 --> Could not find the language line "form_label_content"
ERROR - 2019-11-26 20:49:56 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-26 20:49:56 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-26 20:50:19 --> Could not find the language line "form_label_content"
ERROR - 2019-11-26 20:50:19 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-26 20:50:19 --> Could not find the language line "form_label_picture"
