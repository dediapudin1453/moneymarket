<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-08 06:01:08 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-13/application/views/mod/homepage/view_edit.php 35
