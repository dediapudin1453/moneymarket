<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-04 14:30:31 --> Query error: Column 'os' cannot be null - Invalid query: INSERT INTO `t_visitor` (`ip`, `platform`, `os`, `browser`, `country`, `city`, `date`, `hits`, `url`) VALUES ('182.50.135.35', '', NULL, '', 'US', 'Scottsdale', '2020-06-04', 1, '/pages/contact-us')
ERROR - 2020-06-04 14:30:32 --> Query error: Column 'os' cannot be null - Invalid query: INSERT INTO `t_visitor` (`ip`, `platform`, `os`, `browser`, `country`, `city`, `date`, `hits`, `url`) VALUES ('182.50.135.35', '', NULL, '', 'US', 'Scottsdale', '2020-06-04', 1, '/pages/contact-us')
