<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-11 12:15:30 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 12:29:12 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 12:29:12 --> Severity: Notice --> Undefined index: bank /home/qx59rn1k06vg/public_html/application/views/member/account.php 69
ERROR - 2020-05-11 12:29:12 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 12:29:12 --> Severity: Notice --> Undefined index: norekening /home/qx59rn1k06vg/public_html/application/views/member/account.php 77
ERROR - 2020-05-11 12:29:12 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 12:29:12 --> Severity: Notice --> Undefined index: atasnama /home/qx59rn1k06vg/public_html/application/views/member/account.php 88
ERROR - 2020-05-11 12:29:12 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 12:29:12 --> Severity: Notice --> Undefined index: cabang /home/qx59rn1k06vg/public_html/application/views/member/account.php 96
ERROR - 2020-05-11 12:30:28 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 12:30:28 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 12:30:28 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 12:30:28 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 12:31:07 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 12:31:07 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 12:31:07 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 12:31:07 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 12:56:56 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 12:56:56 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 12:56:56 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 12:56:56 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 13:30:30 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 13:30:30 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 13:30:30 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 13:30:30 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 13:31:43 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 13:31:43 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 13:31:43 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 13:31:43 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 13:36:51 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 13:36:51 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 13:36:51 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 13:36:51 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 13:55:38 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 13:55:38 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 13:55:38 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 13:55:38 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:08:49 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:08:49 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:08:49 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:08:49 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:09:25 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:09:25 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:09:25 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:09:25 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:09:28 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:09:28 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:09:28 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:09:28 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:12:00 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:12:00 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:12:00 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:12:00 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:12:26 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:12:26 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:12:26 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:12:26 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:12:30 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:12:30 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:12:30 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:12:30 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:14:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 14:14:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 14:14:38 --> Query error: Unknown column 'referral_id' in 'where clause' - Invalid query: SELECT *
FROM `t_user`
WHERE `referral_id` = '4'
GROUP BY `id`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-11 14:15:57 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 14:15:58 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 14:15:58 --> Query error: Unknown column 'referral_id' in 'where clause' - Invalid query: SELECT *
FROM `t_user`
WHERE `referral_id` = '4'
GROUP BY `id`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-11 14:16:18 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 14:16:18 --> Query error: Unknown column 'referral_id' in 'where clause' - Invalid query: SELECT *
FROM `t_user`
WHERE `referral_id` = '4'
GROUP BY `id`
ORDER BY `id` DESC
ERROR - 2020-05-11 14:19:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 14:19:17 --> Query error: Unknown column 'referral_id' in 'where clause' - Invalid query: SELECT *
FROM `t_user`
WHERE `referral_id` = '3'
GROUP BY `id`
ORDER BY `id` DESC
ERROR - 2020-05-11 14:29:52 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:29:52 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:29:52 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:29:52 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:30:15 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:30:15 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:30:15 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:30:15 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:30:17 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:30:17 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:30:17 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:30:17 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:30:26 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:30:26 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:30:26 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:30:26 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:32:48 --> Severity: error --> Exception: syntax error, unexpected end of file /home/qx59rn1k06vg/public_html/application/views/member/account.php 145
ERROR - 2020-05-11 14:32:50 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:32:50 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:32:50 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:32:50 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:33:41 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 14:33:41 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 14:33:41 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 14:33:41 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 14:49:51 --> Language file contains no data: language/indonesia/member_lang.php
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "ci_member"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "home_title"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "ci_member"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "menu_dashboard"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "menu_account"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "menu_write_post"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "menu_view_site"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "home1"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "home2"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "home3"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "home4"
ERROR - 2020-05-11 14:49:51 --> Could not find the language line "change_password"
ERROR - 2020-05-11 15:20:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:20:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:20:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:20:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:21:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:21:14 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 15:21:14 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 15:21:14 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 15:21:14 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 15:21:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:21:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:21:45 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:23:49 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 15:23:49 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 15:23:49 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 15:23:49 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 15:23:53 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:23:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:25:57 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:25:57 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:28:26 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:28:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:28:29 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-11 15:28:29 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-11 15:30:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:30:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:30:38 --> Severity: Notice --> Undefined property: Withdrawal::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Withdrawal.php 29
ERROR - 2020-05-11 15:30:38 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Withdrawal.php 29
ERROR - 2020-05-11 15:36:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:36:26 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:36:26 --> Severity: Notice --> Undefined property: Internal_transfer::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 29
ERROR - 2020-05-11 15:36:26 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 29
ERROR - 2020-05-11 15:37:59 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:38:00 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 15:38:00 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-11 15:38:00 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-11 15:44:48 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 15:44:48 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 15:44:48 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 15:44:48 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 15:54:03 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 15:54:03 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 15:54:03 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 15:54:03 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 15:54:10 --> Severity: error --> Exception: Call to private method Login::_cek_username_register() from context 'CI_Form_validation' /home/qx59rn1k06vg/public_html/system/libraries/Form_validation.php 723
ERROR - 2020-05-11 15:56:05 --> Severity: error --> Exception: Call to undefined method Member_login_model::cek_username() /home/qx59rn1k06vg/public_html/application/controllers/l-member/Login.php 507
ERROR - 2020-05-11 16:06:06 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:10:22 --> Severity: error --> Exception: Call to undefined method Test::_sendEmail() /home/qx59rn1k06vg/public_html/application/controllers/Test.php 21
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: activation_key /home/qx59rn1k06vg/public_html/application/controllers/Test.php 28
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: website_email /home/qx59rn1k06vg/public_html/application/controllers/Test.php 36
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 36
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 38
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: full_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 41
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 42
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 43
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: email /home/qx59rn1k06vg/public_html/application/controllers/Test.php 47
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: pass /home/qx59rn1k06vg/public_html/application/controllers/Test.php 48
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 51
ERROR - 2020-05-11 16:10:38 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 51
ERROR - 2020-05-11 16:10:38 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:11:19 --> Severity: Notice --> Undefined variable: website_email /home/qx59rn1k06vg/public_html/application/controllers/Test.php 30
ERROR - 2020-05-11 16:11:19 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 30
ERROR - 2020-05-11 16:11:19 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 32
ERROR - 2020-05-11 16:11:19 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 36
ERROR - 2020-05-11 16:11:19 --> Severity: Notice --> Undefined variable: website_name /home/qx59rn1k06vg/public_html/application/controllers/Test.php 36
ERROR - 2020-05-11 16:11:19 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:14:08 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:20:32 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:20:37 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:23:57 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:24:08 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:24:57 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:587 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:25:02 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:587 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:25:19 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:143 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:25:21 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:143 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:25:35 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:143 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:25:46 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:25:57 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:26:04 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:587 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 16:32:05 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 16:32:05 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 16:32:05 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 16:32:05 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 16:32:11 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 16:32:11 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 16:32:11 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 16:32:11 --> Could not find the language line "account_label_cabang"
ERROR - 2020-05-11 17:05:15 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:05:15 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:05:48 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:05:48 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:05:59 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:05:59 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:06:02 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:06:02 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail:587 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:07:07 --> Severity: Warning --> fsockopen(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:07:07 --> Severity: Warning --> fsockopen(): unable to connect to smtp.gmail:465 (php_network_getaddresses: getaddrinfo failed: Name or service not known) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:11:16 --> Severity: Warning --> fsockopen(): unable to connect to mail.linggabuana.com:465 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:12:19 --> Severity: Warning --> fsockopen(): unable to connect to mail.linggabuana.com:587 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 17:12:23 --> Severity: Warning --> fsockopen(): unable to connect to mail.linggabuana.com:587 (Connection refused) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-11 19:55:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:55:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:55:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:55:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:55:27 --> Severity: Notice --> Undefined property: Deposit::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-11 19:55:27 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 29
ERROR - 2020-05-11 19:55:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:55:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:55:38 --> Severity: Notice --> Undefined property: Withdrawal::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Withdrawal.php 29
ERROR - 2020-05-11 19:55:38 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Withdrawal.php 29
ERROR - 2020-05-11 19:55:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:55:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:55:41 --> Severity: Notice --> Undefined property: Internal_transfer::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 29
ERROR - 2020-05-11 19:55:41 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 29
ERROR - 2020-05-11 19:56:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:05 --> Severity: Notice --> Undefined property: Withdrawal::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Withdrawal.php 29
ERROR - 2020-05-11 19:56:05 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Withdrawal.php 29
ERROR - 2020-05-11 19:56:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:20 --> Severity: Notice --> Undefined property: Internal_transfer::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 29
ERROR - 2020-05-11 19:56:20 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Internal_transfer.php 29
ERROR - 2020-05-11 19:56:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:24 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-11 19:56:24 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-11 19:56:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:38 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-11 19:56:38 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-11 19:56:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:41 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-11 19:56:41 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-11 19:56:58 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:58 --> Could not find the language line "referral_title"
ERROR - 2020-05-11 19:56:58 --> Severity: Notice --> Undefined property: History_report::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-11 19:56:58 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/History_report.php 29
ERROR - 2020-05-11 19:57:02 --> Could not find the language line "account_label_bank"
ERROR - 2020-05-11 19:57:02 --> Could not find the language line "account_label_norekening"
ERROR - 2020-05-11 19:57:02 --> Could not find the language line "account_label_atasnama"
ERROR - 2020-05-11 19:57:02 --> Could not find the language line "account_label_cabang"
