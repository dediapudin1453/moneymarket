<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-03 14:53:08 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\demoforex\application\config\user_agents.php 14
ERROR - 2021-06-03 14:56:51 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 14:57:48 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 14:58:01 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 14:58:01 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 14:58:27 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 14:58:40 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:00:55 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:01:08 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:01:53 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:02:27 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:02:38 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:04:05 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:04:40 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:05:56 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:07:01 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:09:57 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\demoforex\system\libraries\Email.php 1902
ERROR - 2021-06-03 15:10:15 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:11:36 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\demoforex\system\libraries\Email.php 1902
ERROR - 2021-06-03 15:12:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\demoforex\system\libraries\Email.php 1902
ERROR - 2021-06-03 15:12:31 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:13:52 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:14:24 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 15:49:10 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 16:36:51 --> Could not find the language line "referral_title"
ERROR - 2021-06-03 17:10:03 --> Could not find the language line "referral_title"
