<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-03 11:59:06 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:16:34 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:26:04 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:33:28 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:33:45 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:34:00 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:34:25 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:35:00 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:35:12 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:35:32 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 12:46:31 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 13:12:34 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 13:16:23 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 13:22:21 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 13:29:09 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 13:46:47 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 14:58:16 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 14:58:53 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 14:59:35 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 15:00:33 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 15:02:21 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 15:02:45 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 16:11:31 --> Severity: Notice --> Undefined variable: data /home/suodo7dumzff/public_html/application/controllers/l-member/Account.php 475
ERROR - 2021-02-03 18:34:44 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:34:56 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:35:00 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:35:01 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:35:04 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:35:05 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:35:07 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:38:55 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:39:00 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:42:40 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:55:08 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:55:10 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:55:12 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:55:13 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:55:15 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:55:16 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:55:44 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 18:55:46 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 19:15:29 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 19:15:42 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 19:15:48 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 19:16:11 --> Severity: Notice --> Undefined index: seotitle /home/suodo7dumzff/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-02-03 19:29:48 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 19:29:59 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 19:30:07 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 19:30:08 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 19:31:26 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 19:31:29 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:05:17 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:06:41 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:06:42 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:06:44 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:06:45 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:06:46 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:06:48 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:08:46 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:10:20 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:10:22 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:10:24 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:10:25 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:10:26 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:10:28 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:10:30 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:10:31 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:11:57 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:12:12 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:28 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:29 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:31 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:32 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:33 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:37 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:37 --> Severity: Notice --> Undefined variable: data /home/suodo7dumzff/public_html/application/controllers/l-member/Account.php 475
ERROR - 2021-02-03 20:14:47 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:52 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:53 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:14:58 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:15:12 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:15:18 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:15:35 --> Could not find the language line "form_label_title"
ERROR - 2021-02-03 20:15:51 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:15:51 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:17:23 --> Query error: Column 'date' in order clause is ambiguous - Invalid query: SELECT *, `t_account_receiver`.`id` as `id`
FROM `t_account_receiver`
JOIN `t_account_trading` ON `t_account_trading`.`id`=`t_account_receiver`.`account_id`
JOIN `t_user` ON `t_user`.`id`=`t_account_trading`.`user_id`
ORDER BY `username` ASC, `account` ASC, `date` ASC
 LIMIT 10
ERROR - 2021-02-03 20:37:47 --> Severity: Notice --> Undefined variable: data /home/suodo7dumzff/public_html/application/controllers/l-member/Account.php 475
ERROR - 2021-02-03 20:38:55 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:39:08 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:39:21 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:39:21 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:43:47 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:44:13 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:49:03 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 20:49:06 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:03:49 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:04:22 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:04:28 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:17:39 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:18:05 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:18:19 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:18:22 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:18:30 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:18:39 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:21:11 --> Severity: Notice --> Undefined variable: data /home/suodo7dumzff/public_html/application/controllers/l-member/Account.php 475
ERROR - 2021-02-03 21:22:13 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:22:36 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:43:07 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:47:58 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:58:56 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:58:59 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 21:59:07 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:35:10 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:35:49 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:36:07 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:39:40 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:40:04 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:40:34 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:41:13 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:41:47 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:41:56 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 22:44:58 --> Could not find the language line "referral_title"
ERROR - 2021-02-03 23:34:20 --> Could not find the language line "referral_title"
