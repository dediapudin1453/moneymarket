<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-14 01:40:15 --> Could not find the language line "table_content"
ERROR - 2019-11-14 01:40:33 --> Could not find the language line "table_content"
ERROR - 2019-11-14 01:41:21 --> Could not find the language line "table_content"
ERROR - 2019-11-14 01:41:35 --> Could not find the language line "table_content"
ERROR - 2019-11-14 01:41:39 --> Could not find the language line "table_content"
ERROR - 2019-11-14 13:59:53 --> Could not find the language line "table_content"
ERROR - 2019-11-14 14:06:26 --> Severity: Notice --> Undefined variable: footer /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/footer.php 32
ERROR - 2019-11-14 14:06:29 --> Severity: Notice --> Undefined variable: footer /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/footer.php 32
