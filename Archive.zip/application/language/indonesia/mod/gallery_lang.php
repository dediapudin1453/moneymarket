<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Galeri';
$lang['mod_title_all'] = 'Semua Galeri';
$lang['mod_title_album'] = 'Album';
$lang['button_add_album'] = 'Tambah Album';
$lang['button_delete_album'] = 'Hapus Album';
$lang['button_add_picture'] = 'Tambah Gambar';
$lang['form_label_title'] = 'Judul';
$lang['form_label_title_album'] = 'Judul Album';
$lang['form_label_picture'] = 'Gambar';
$lang['dialog_title_add_album'] = 'Tambah Album';
$lang['dialog_title_add_picture'] = 'Tambah Gambar';
$lang['dialog_delete_content_album'] = '<b>Perhatian !</b><br><p>Jika album ini di hapus makan akan menghapus seluru gambar pada album ini.</p><p>Anda yakin akan menghapus album ini ?</p>';
$lang['dialog_delete_content_picture'] = 'Anda yakin akan menghapus gambar ini ?';