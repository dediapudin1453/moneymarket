<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-22 06:44:47 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-04-22 06:48:03 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
