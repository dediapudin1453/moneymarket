<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-22 22:48:31 --> Severity: Notice --> Undefined variable: titletesti /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-15-98b6388b92c374b9d9b8f773c04c56a9/home.php 192
ERROR - 2019-11-22 22:48:31 --> Severity: Notice --> Undefined variable: titletesti /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-15-98b6388b92c374b9d9b8f773c04c56a9/home.php 193
ERROR - 2019-11-22 22:48:31 --> Severity: Notice --> Undefined variable: testimoni /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-15-98b6388b92c374b9d9b8f773c04c56a9/home.php 199
ERROR - 2019-11-22 22:48:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-15-98b6388b92c374b9d9b8f773c04c56a9/home.php 199
ERROR - 2019-11-22 22:48:31 --> Severity: Notice --> Undefined variable: titlecta /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-15-98b6388b92c374b9d9b8f773c04c56a9/home.php 220
ERROR - 2019-11-22 22:48:31 --> Severity: Notice --> Undefined variable: titlecta /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-15-98b6388b92c374b9d9b8f773c04c56a9/home.php 221
