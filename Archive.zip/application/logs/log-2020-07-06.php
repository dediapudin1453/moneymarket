<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-06 15:03:50 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-07-06 16:22:11 --> Could not find the language line "referral_title"
ERROR - 2020-07-06 16:22:15 --> Could not find the language line "referral_title"
ERROR - 2020-07-06 16:22:21 --> Could not find the language line "referral_title"
ERROR - 2020-07-06 16:22:25 --> Could not find the language line "referral_title"
ERROR - 2020-07-06 16:22:30 --> Could not find the language line "referral_title"
ERROR - 2020-07-06 16:22:32 --> Could not find the language line "referral_title"
ERROR - 2020-07-06 16:22:32 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-07-06 16:22:32 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-07-06 16:22:32 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-07-06 16:22:39 --> Could not find the language line "referral_title"
ERROR - 2020-07-06 16:26:18 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-07-06 16:26:20 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-07-06 16:26:25 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
