<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-30 19:56:34 --> Could not find the language line "referral_title"
ERROR - 2020-06-30 19:56:34 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-06-30 19:56:34 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-06-30 19:56:34 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-06-30 19:56:46 --> Could not find the language line "referral_title"
ERROR - 2020-06-30 19:56:46 --> Could not find the language line "referral_title"
ERROR - 2020-06-30 19:58:25 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account.php 475
ERROR - 2020-06-30 20:09:09 --> Could not find the language line "form_label_title"
