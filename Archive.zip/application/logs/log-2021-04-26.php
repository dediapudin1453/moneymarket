<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-26 04:25:53 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 41
ERROR - 2021-04-26 04:25:54 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 41
ERROR - 2021-04-26 04:35:54 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 39
ERROR - 2021-04-26 04:35:57 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 39
