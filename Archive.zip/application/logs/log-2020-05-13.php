<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-13 09:43:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 09:50:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 09:50:48 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 09:53:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 09:53:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:27:53 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:28:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:29:19 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:29:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:31:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:31:02 --> 404 Page Not Found: 
ERROR - 2020-05-13 10:31:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:31:04 --> 404 Page Not Found: 
ERROR - 2020-05-13 10:31:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:31:07 --> 404 Page Not Found: 
ERROR - 2020-05-13 10:31:10 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:31:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:31:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:32:13 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:36:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:38:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:38:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:39:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:40:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:40:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:41:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:41:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:41:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:42:18 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:43:26 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:43:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:44:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:44:30 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:45:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:46:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:47:03 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:48:19 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:48:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:51:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 10:51:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:04:59 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:05:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:12:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:14:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:15:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:15:27 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:18:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:19:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:19:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:19:53 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 11:20:58 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 13:13:28 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 13:13:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 13:14:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 13:14:32 --> Severity: Notice --> Undefined property: Account_trading::$referral_model /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-13 13:14:32 --> Severity: error --> Exception: Call to a member function get_datatables() on null /home/qx59rn1k06vg/public_html/application/controllers/l-member/Account_trading.php 29
ERROR - 2020-05-13 13:17:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 13:35:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 13:35:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 13:54:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 13:54:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:04:16 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:04:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:04:41 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:06:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:06:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:07:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:07:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:07:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:09:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:11:19 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:12:31 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:12:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:12:50 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:14:57 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:18:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:18:14 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:18:43 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:19:00 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:19:16 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:19:55 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:20:10 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:26:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:26:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:40:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:58:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 14:58:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:08:09 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:22:20 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:22:20 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 181
ERROR - 2020-05-13 15:22:21 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:22:59 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:23:00 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:23:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:23:02 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 181
ERROR - 2020-05-13 15:23:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:23:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:23:23 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 181
ERROR - 2020-05-13 15:23:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:23:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:23:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:23:56 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 181
ERROR - 2020-05-13 15:23:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:25:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:25:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:25:34 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 181
ERROR - 2020-05-13 15:25:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:26:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:26:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:26:33 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 176
ERROR - 2020-05-13 15:26:33 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:26:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:26:42 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 176
ERROR - 2020-05-13 15:26:42 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:29:45 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:29:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:29:47 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 176
ERROR - 2020-05-13 15:29:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:30:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:30:05 --> Severity: Notice --> Undefined variable: data /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 176
ERROR - 2020-05-13 15:30:06 --> Severity: error --> Exception: Call to undefined method Deposit_model::input_deposit() /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 75
ERROR - 2020-05-13 15:30:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:30:26 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:30:30 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:30:30 --> Severity: Notice --> Undefined index: foto /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 71
ERROR - 2020-05-13 15:30:30 --> Severity: error --> Exception: Call to undefined method Deposit_model::input_deposit() /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 75
ERROR - 2020-05-13 15:32:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:32:26 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:32:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:32:29 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:33:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:33:02 --> Could not find the language line "form_validation_validate_fotoid"
ERROR - 2020-05-13 15:33:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:33:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:33:24 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:33:30 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:33:31 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:36:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:36:25 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:36:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:36:38 --> Severity: Notice --> Undefined variable: error /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 182
ERROR - 2020-05-13 15:36:38 --> Could not find the language line "form_validation_validate_fotoid"
ERROR - 2020-05-13 15:36:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:37:00 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:37:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:37:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:37:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:37:06 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:39:23 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:40:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:40:04 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:40:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:40:05 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:40:17 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:40:17 --> Severity: error --> Exception: Call to undefined method Deposit_model::input_deposit() /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 75
ERROR - 2020-05-13 15:40:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:41:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 15:41:01 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 16:19:28 --> Severity: Notice --> Undefined index: name /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 33
ERROR - 2020-05-13 16:19:28 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 39
ERROR - 2020-05-13 16:19:28 --> Severity: Notice --> Undefined index: name /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 33
ERROR - 2020-05-13 16:19:28 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 39
ERROR - 2020-05-13 16:19:47 --> Severity: Notice --> Undefined index: name /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 33
ERROR - 2020-05-13 16:19:47 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 39
ERROR - 2020-05-13 16:19:47 --> Severity: Notice --> Undefined index: name /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 33
ERROR - 2020-05-13 16:19:47 --> Severity: Notice --> Undefined index: status /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 39
ERROR - 2020-05-13 16:21:41 --> Query error: Unknown column 't_rate.user_id' in 'on clause' - Invalid query: SELECT *
FROM `t_rate`
JOIN `t_user` ON `t_user`.`id`=`t_rate`.`user_id`
ORDER BY `id` DESC
ERROR - 2020-05-13 16:22:13 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `t_deposit`
JOIN `t_user` ON `t_user`.`id`=`t_deposit`.`user_id`
ORDER BY `id` DESC
ERROR - 2020-05-13 16:22:46 --> Query error: Unknown column 't_depositid' in 'order clause' - Invalid query: SELECT *
FROM `t_deposit`
JOIN `t_user` ON `t_user`.`id`=`t_deposit`.`user_id`
ORDER BY `t_depositid` DESC
ERROR - 2020-05-13 16:26:11 --> Query error: Unknown column 'bank_name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
JOIN `t_user` ON `t_user`.`id`=`t_deposit`.`user_id`
WHERE   (
`bank_name` LIKE '%p%' ESCAPE '!'
OR  `amount` LIKE '%p%' ESCAPE '!'
OR  `rate_amount` LIKE '%p%' ESCAPE '!'
OR  `amount_usd` LIKE '%p%' ESCAPE '!'
OR  `date` LIKE '%p%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 16:29:14 --> Query error: Unknown column 'bank_name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
JOIN `t_user` ON `t_user`.`id`=`t_deposit`.`user_id`
WHERE   (
`bank_name` LIKE '%a%' ESCAPE '!'
OR  `amount` LIKE '%a%' ESCAPE '!'
OR  `rate_amount` LIKE '%a%' ESCAPE '!'
OR  `amount_usd` LIKE '%a%' ESCAPE '!'
OR  `date` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 16:43:39 --> Query error: Unknown column 'bank_name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
JOIN `t_user` ON `t_user`.`id`=`t_deposit`.`user_id`
WHERE   (
`bank_name` LIKE '%a%' ESCAPE '!'
OR  `amount` LIKE '%a%' ESCAPE '!'
OR  `rate_amount` LIKE '%a%' ESCAPE '!'
OR  `amount_usd` LIKE '%a%' ESCAPE '!'
OR  `date` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 16:53:58 --> Query error: Unknown column 'bank_name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
JOIN `t_user` ON `t_user`.`id`=`t_deposit`.`user_id`
WHERE   (
`name` LIKE '%s%' ESCAPE '!'
OR  `bank_name` LIKE '%s%' ESCAPE '!'
OR  `amount` LIKE '%s%' ESCAPE '!'
OR  `rate_amount` LIKE '%s%' ESCAPE '!'
OR  `amount_usd` LIKE '%s%' ESCAPE '!'
OR  `date` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 16:54:00 --> Query error: Unknown column 'bank_name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
JOIN `t_user` ON `t_user`.`id`=`t_deposit`.`user_id`
WHERE   (
`name` LIKE '%sa%' ESCAPE '!'
OR  `bank_name` LIKE '%sa%' ESCAPE '!'
OR  `amount` LIKE '%sa%' ESCAPE '!'
OR  `rate_amount` LIKE '%sa%' ESCAPE '!'
OR  `amount_usd` LIKE '%sa%' ESCAPE '!'
OR  `date` LIKE '%sa%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 16:57:37 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 16:57:39 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 16:57:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 16:57:56 --> Could not find the language line "referral_title"
ERROR - 2020-05-13 16:58:11 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%a%' ESCAPE '!'
OR  `bank_name` LIKE '%a%' ESCAPE '!'
OR  `amount` LIKE '%a%' ESCAPE '!'
OR  `rate_amount` LIKE '%a%' ESCAPE '!'
OR  `amount_usd` LIKE '%a%' ESCAPE '!'
OR  `date` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 16:58:35 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%a%' ESCAPE '!'
OR  `bank_name` LIKE '%a%' ESCAPE '!'
OR  `amount` LIKE '%a%' ESCAPE '!'
OR  `rate_amount` LIKE '%a%' ESCAPE '!'
OR  `amount_usd` LIKE '%a%' ESCAPE '!'
OR  `date` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:02:54 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%a%' ESCAPE '!'
OR  `bank_name` LIKE '%a%' ESCAPE '!'
OR  `amount` LIKE '%a%' ESCAPE '!'
OR  `rate_amount` LIKE '%a%' ESCAPE '!'
OR  `amount_usd` LIKE '%a%' ESCAPE '!'
OR  `date` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:03:11 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%d%' ESCAPE '!'
OR  `bank_name` LIKE '%d%' ESCAPE '!'
OR  `amount` LIKE '%d%' ESCAPE '!'
OR  `rate_amount` LIKE '%d%' ESCAPE '!'
OR  `amount_usd` LIKE '%d%' ESCAPE '!'
OR  `date` LIKE '%d%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:03:47 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%a%' ESCAPE '!'
OR  `bank_name` LIKE '%a%' ESCAPE '!'
OR  `amount` LIKE '%a%' ESCAPE '!'
OR  `rate_amount` LIKE '%a%' ESCAPE '!'
OR  `amount_usd` LIKE '%a%' ESCAPE '!'
OR  `date` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:05:16 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%s%' ESCAPE '!'
OR  `bank_name` LIKE '%s%' ESCAPE '!'
OR  `amount` LIKE '%s%' ESCAPE '!'
OR  `rate_amount` LIKE '%s%' ESCAPE '!'
OR  `amount_usd` LIKE '%s%' ESCAPE '!'
OR  `date` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:05:42 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%s%' ESCAPE '!'
OR  `bank_name` LIKE '%s%' ESCAPE '!'
OR  `amount` LIKE '%s%' ESCAPE '!'
OR  `rate_amount` LIKE '%s%' ESCAPE '!'
OR  `amount_usd` LIKE '%s%' ESCAPE '!'
OR  `date` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:05:59 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%s%' ESCAPE '!'
OR  `bank_name` LIKE '%s%' ESCAPE '!'
OR  `amount` LIKE '%s%' ESCAPE '!'
OR  `rate_amount` LIKE '%s%' ESCAPE '!'
OR  `amount_usd` LIKE '%s%' ESCAPE '!'
OR  `date` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:06:21 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%g%' ESCAPE '!'
OR  `bank_name` LIKE '%g%' ESCAPE '!'
OR  `amount` LIKE '%g%' ESCAPE '!'
OR  `rate_amount` LIKE '%g%' ESCAPE '!'
OR  `amount_usd` LIKE '%g%' ESCAPE '!'
OR  `date` LIKE '%g%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:10:39 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:10:39 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:10:39 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:10:55 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`name` LIKE '%s%' ESCAPE '!'
OR  `bank_name` LIKE '%s%' ESCAPE '!'
OR  `amount` LIKE '%s%' ESCAPE '!'
OR  `rate_amount` LIKE '%s%' ESCAPE '!'
OR  `amount_usd` LIKE '%s%' ESCAPE '!'
OR  `date` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `t_deposit`.`id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:16:46 --> Severity: error --> Exception: /home/qx59rn1k06vg/public_html/application/models/mod/Deposit_model.php exists, but doesn't declare class Deposit_model /home/qx59rn1k06vg/public_html/system/core/Loader.php 340
ERROR - 2020-05-13 17:16:56 --> Severity: error --> Exception: /home/qx59rn1k06vg/public_html/application/models/mod/Deposit_model.php exists, but doesn't declare class Deposit_model /home/qx59rn1k06vg/public_html/system/core/Loader.php 340
ERROR - 2020-05-13 17:16:57 --> Severity: error --> Exception: /home/qx59rn1k06vg/public_html/application/models/mod/Deposit_model.php exists, but doesn't declare class Deposit_model /home/qx59rn1k06vg/public_html/system/core/Loader.php 340
ERROR - 2020-05-13 17:17:06 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:17:06 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:17:06 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:17:09 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:17:09 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:17:09 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:18:27 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:18:27 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:18:27 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:18:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`amount_usd` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`username, bank_name, amount,` `amount_usd` LIKE '%a%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:19:45 --> Severity: error --> Exception: syntax error, unexpected 'search' (T_STRING), expecting ')' /home/qx59rn1k06vg/public_html/application/models/mod/Deposit_model.php 23
ERROR - 2020-05-13 17:19:57 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:19:57 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:19:57 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:19:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`amount` LIKE '%d%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`username, bank_name,` `amount` LIKE '%d%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:20:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`amount` LIKE '%dx%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`username, bank_name,` `amount` LIKE '%dx%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:21:12 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:21:12 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:21:12 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:21:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`amount` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`username,` `amount` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:21:51 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:21:51 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:21:51 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:21:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`amount` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`username,` `amount` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:22:22 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:22:22 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:22:22 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:23:00 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:23:00 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:23:00 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:23:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`amount` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`username,` `amount` LIKE '%s%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:25:39 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:25:39 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:25:39 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:26:04 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:26:04 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:26:04 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:26:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`date` LIKE '%i%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT *
FROM `t_deposit`
WHERE   (
`username,` `date` LIKE '%i%' ESCAPE '!'
 )
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-05-13 17:26:12 --> Could not find the language line "table_title"
ERROR - 2020-05-13 17:26:12 --> Could not find the language line "table_seotitle"
ERROR - 2020-05-13 17:26:12 --> Could not find the language line "table_active"
ERROR - 2020-05-13 17:26:51 --> Severity: Notice --> Undefined index: rate_type /home/qx59rn1k06vg/public_html/application/views/mod/deposit/view_edit.php 23
ERROR - 2020-05-13 17:27:43 --> Severity: error --> Exception: Call to undefined method Deposit_model::get_deposit() /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 81
ERROR - 2020-05-13 17:27:49 --> Severity: error --> Exception: Call to undefined method Deposit_model::get_deposit() /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Deposit.php 81
ERROR - 2020-05-13 17:27:57 --> Severity: Notice --> Undefined index: rate_type /home/qx59rn1k06vg/public_html/application/views/mod/deposit/view_edit.php 23
ERROR - 2020-05-13 17:10:02 --> Severity: error --> Exception: syntax error, unexpected ',' /home/qx59rn1k06vg/public_html/application/controllers/l-member/Deposit.php 69
