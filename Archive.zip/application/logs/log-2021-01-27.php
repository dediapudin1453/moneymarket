<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-27 10:15:28 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/application/controllers/l-member/Account.php 475
ERROR - 2021-01-27 12:35:43 --> Severity: Notice --> Undefined property: Member::$user_model /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 60
ERROR - 2021-01-27 12:35:43 --> Severity: error --> Exception: Call to a member function all_user() on null /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 60
ERROR - 2021-01-27 13:59:50 --> Severity: Notice --> Undefined property: Member::$user_model /home/kqw5yzwxdlcw/public_html/application/views/mod/member/view_add_new.php 44
ERROR - 2021-01-27 13:59:50 --> Severity: error --> Exception: Call to a member function select_level() on null /home/kqw5yzwxdlcw/public_html/application/views/mod/member/view_add_new.php 44
ERROR - 2021-01-27 13:59:54 --> Severity: Notice --> Undefined property: Member::$user_model /home/kqw5yzwxdlcw/public_html/application/views/mod/member/view_add_new.php 44
ERROR - 2021-01-27 13:59:54 --> Severity: error --> Exception: Call to a member function select_level() on null /home/kqw5yzwxdlcw/public_html/application/views/mod/member/view_add_new.php 44
ERROR - 2021-01-27 14:00:18 --> Severity: Notice --> Undefined property: Member::$user_model /home/kqw5yzwxdlcw/public_html/application/views/mod/member/view_add_new.php 44
ERROR - 2021-01-27 14:00:18 --> Severity: error --> Exception: Call to a member function select_level() on null /home/kqw5yzwxdlcw/public_html/application/views/mod/member/view_add_new.php 44
ERROR - 2021-01-27 14:02:19 --> Could not find the language line "referral_title"
ERROR - 2021-01-27 14:02:22 --> Could not find the language line "referral_title"
ERROR - 2021-01-27 14:02:24 --> Could not find the language line "referral_title"
ERROR - 2021-01-27 14:02:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-27 14:02:26 --> Could not find the language line "referral_title"
ERROR - 2021-01-27 14:02:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-27 14:02:28 --> Could not find the language line "referral_title"
ERROR - 2021-01-27 14:02:30 --> Could not find the language line "referral_title"
ERROR - 2021-01-27 14:05:14 --> Severity: Notice --> Undefined variable: id /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 225
ERROR - 2021-01-27 14:05:14 --> 404 Page Not Found: 
ERROR - 2021-01-27 14:22:57 --> Could not find the language line "form_label_username"
ERROR - 2021-01-27 14:22:57 --> Could not find the language line "form_label_username_note"
ERROR - 2021-01-27 14:23:27 --> Could not find the language line "form_label_username"
ERROR - 2021-01-27 14:23:27 --> Could not find the language line "form_label_username_note"
ERROR - 2021-01-27 15:05:10 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 405
ERROR - 2021-01-27 15:05:10 --> Severity: error --> Exception: Argument 2 passed to Member_model::update() must be of the type array, null given, called in /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php on line 405 /home/kqw5yzwxdlcw/public_html/application/models/mod/Member_model.php 220
ERROR - 2021-01-27 15:57:01 --> 404 Page Not Found: 
ERROR - 2021-01-27 09:09:35 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 434
ERROR - 2021-01-27 09:10:00 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 434
ERROR - 2021-01-27 09:26:22 --> Severity: error --> Exception: syntax error, unexpected 'array' (T_ARRAY), expecting ')' /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 228
ERROR - 2021-01-27 09:26:38 --> Severity: error --> Exception: syntax error, unexpected 'array' (T_ARRAY), expecting ')' /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 228
ERROR - 2021-01-27 09:26:39 --> Severity: error --> Exception: syntax error, unexpected 'array' (T_ARRAY), expecting ')' /home/kqw5yzwxdlcw/public_html/application/controllers/l-admin/Member.php 228
ERROR - 2021-01-27 16:46:02 --> Severity: Notice --> Undefined property: Member::$user_model /home/kqw5yzwxdlcw/public_html/application/views/mod/member/view_add_new.php 44
ERROR - 2021-01-27 16:46:02 --> Severity: error --> Exception: Call to a member function select_level() on null /home/kqw5yzwxdlcw/public_html/application/views/mod/member/view_add_new.php 44
ERROR - 2021-01-27 19:33:03 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/application/controllers/l-member/Account.php 475
