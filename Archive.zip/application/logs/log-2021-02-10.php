<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-10 03:23:27 --> Severity: error --> Exception: syntax error, unexpected 'validation_errors' (T_STRING), expecting ')' /home/u3110812/public_html/linggafx/application/controllers/l-member/Login.php 118
ERROR - 2021-02-10 11:50:56 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\l-member\Login.php 105
ERROR - 2021-02-10 17:51:17 --> Severity: error --> Exception: Call to undefined function get_cookie() C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\application\controllers\l-member\Login.php 56
ERROR - 2021-02-10 17:54:51 --> Query error: Unknown column 'cookie' in 'field list' - Invalid query: UPDATE `t_user` SET `cookie` = 'uA8Wbkyqa6eoSxBzPxgzL1ToYHZrk8OH1eMV0DsKUq2BKRiNV9dh9jZpWy3Sftw3'
WHERE `id` = '9'
ERROR - 2021-02-10 19:15:40 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\kerjaan-kutakkatik\linggaforex\system\libraries\Email.php 1902
