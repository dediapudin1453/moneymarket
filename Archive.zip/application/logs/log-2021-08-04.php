<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-04 10:56:34 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/header.php 121
ERROR - 2021-08-04 10:56:34 --> Severity: Notice --> Undefined variable: titlecta /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-08-04 10:56:34 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-08-04 10:59:14 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/header.php 121
ERROR - 2021-08-04 10:59:14 --> Severity: Notice --> Undefined variable: titlecta /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-08-04 10:59:14 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-08-04 11:12:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/header.php 121
ERROR - 2021-08-04 11:12:48 --> Severity: Notice --> Undefined variable: titlecta /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-08-04 11:12:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-08-04 13:55:31 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/header.php 121
ERROR - 2021-08-04 13:55:31 --> Severity: Notice --> Undefined variable: titlecta /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-08-04 13:55:31 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
