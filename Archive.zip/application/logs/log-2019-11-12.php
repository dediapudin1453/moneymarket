<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-12 14:51:28 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 14:51:28 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 14:57:21 --> Could not find the language line "table_title"
ERROR - 2019-11-12 14:57:31 --> Could not find the language line "table_title"
ERROR - 2019-11-12 15:37:15 --> Severity: Warning --> Error while sending QUERY packet. PID=219488 /home/u7014999/public_html/websitepraktis/system/database/drivers/pdo/pdo_driver.php 184
ERROR - 2019-11-12 15:37:15 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_visitor`
WHERE `ip` = '140.213.2.159'
AND `date` = '2019-11-12'
AND `url` = '/websitepraktis/img/blog/blog-corporate-3-1.jpg'
ERROR - 2019-11-12 15:37:16 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 15:37:16 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 16:31:22 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 144
ERROR - 2019-11-12 16:31:45 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 144
ERROR - 2019-11-12 16:33:05 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 144
ERROR - 2019-11-12 16:46:52 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 144
ERROR - 2019-11-12 18:43:53 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `t_homepage` (`name`, `comment`, `picture`, `active`) VALUES ('Judul Product', '&lt;p&gt;Subjudul Product&lt;/p&gt;', '', 'Y')
ERROR - 2019-11-12 18:54:05 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `t_homepage` (`name`, `comment`, `picture`, `active`) VALUES ('judul product', '&lt;p&gt;bawahnya judul&lt;/p&gt;', '', 'Y')
ERROR - 2019-11-12 18:55:42 --> Query error: Unknown column 'title' in 'order clause' - Invalid query: SELECT *
FROM `t_homepage`
ORDER BY `title` ASC
 LIMIT 10
ERROR - 2019-11-12 18:56:51 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 18:56:51 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 18:57:24 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 18:57:24 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 19:06:06 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 19:06:06 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 19:23:50 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 19:23:50 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 19:48:08 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 19:48:08 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 21:02:05 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 21:02:05 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 21:05:08 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 21:05:08 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-12 21:07:04 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 21:09:53 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-12 21:34:09 --> Could not find the language line "table_content"
ERROR - 2019-11-12 21:34:09 --> Could not find the language line "table_active"
ERROR - 2019-11-12 21:36:15 --> Could not find the language line "table_content"
ERROR - 2019-11-12 21:36:15 --> Could not find the language line "table_active"
ERROR - 2019-11-12 21:38:19 --> Could not find the language line "table_content"
ERROR - 2019-11-12 21:38:19 --> Could not find the language line "table_active"
ERROR - 2019-11-12 21:39:15 --> Could not find the language line "table_content"
ERROR - 2019-11-12 21:41:17 --> Could not find the language line "form_label_title"
ERROR - 2019-11-12 21:43:22 --> Could not find the language line "table_content"
ERROR - 2019-11-12 21:44:49 --> Could not find the language line "table_content"
ERROR - 2019-11-12 21:51:29 --> Could not find the language line "table_content"
