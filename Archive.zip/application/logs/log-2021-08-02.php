<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-02 07:22:29 --> Severity: Notice --> getimagesize(): read of 8192 bytes failed with errno=21 Is a directory /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 07:22:29 --> Severity: Notice --> getimagesize(): Read error! /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 07:22:29 --> Severity: error --> Exception: Invalid image file: content/uploads/user/ /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 124
ERROR - 2021-08-02 09:21:30 --> Severity: Notice --> getimagesize(): read of 8192 bytes failed with errno=21 Is a directory /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 09:21:30 --> Severity: Notice --> getimagesize(): Read error! /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 09:21:30 --> Severity: error --> Exception: Invalid image file: content/uploads/user/ /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 124
ERROR - 2021-08-02 09:40:34 --> Severity: Notice --> getimagesize(): read of 8192 bytes failed with errno=21 Is a directory /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 09:40:34 --> Severity: Notice --> getimagesize(): Read error! /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 09:40:34 --> Severity: error --> Exception: Invalid image file: content/uploads/user/ /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 124
ERROR - 2021-08-02 09:43:06 --> Severity: Notice --> getimagesize(): read of 8192 bytes failed with errno=21 Is a directory /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 09:43:06 --> Severity: Notice --> getimagesize(): Read error! /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 09:43:06 --> Severity: error --> Exception: Invalid image file: content/uploads/user/ /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 124
ERROR - 2021-08-02 09:43:10 --> Severity: Notice --> getimagesize(): read of 8192 bytes failed with errno=21 Is a directory /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 09:43:10 --> Severity: Notice --> getimagesize(): Read error! /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-08-02 09:43:10 --> Severity: error --> Exception: Invalid image file: content/uploads/user/ /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 124
