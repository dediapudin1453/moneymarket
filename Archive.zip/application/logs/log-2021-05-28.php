<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 00:00:44 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 00:00:56 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 00:02:03 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/demoforex/application/views/mod/member/view_edit.php 249
ERROR - 2021-05-28 00:02:03 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/demoforex/application/views/mod/member/view_edit.php 250
ERROR - 2021-05-28 00:02:03 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/demoforex/application/views/mod/member/view_edit.php 257
ERROR - 2021-05-28 00:02:03 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/demoforex/application/views/mod/member/view_edit.php 266
ERROR - 2021-05-28 00:02:03 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/demoforex/application/views/mod/member/view_edit.php 275
ERROR - 2021-05-28 00:02:03 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/demoforex/application/views/mod/member/view_edit.php 283
ERROR - 2021-05-28 00:07:09 --> Query error: Unknown column 't_user.level_ib' in 'field list' - Invalid query: SELECT `t_user`.`id` AS `user_id`, `t_user`.`username` AS `user_username`, `t_user`.`password` AS `user_password`, `t_user`.`email` AS `user_email`, `t_user`.`name` AS `user_name`, `t_user`.`gender` AS `user_gender`, `t_user`.`birthday` AS `user_birthday`, `t_user`.`about` AS `user_about`, `t_user`.`address` AS `user_address`, `t_user`.`tlpn` AS `user_tlpn`, `t_user`.`id_type` AS `user_idtype`, `t_user`.`id_number` AS `user_idnumber`, `t_user`.`id_photo` AS `user_idphoto`, `t_user`.`photo` AS `user_photo`, `t_user`.`active` AS `user_active`, `t_user`.`level_ib` AS `user_level_ib`, `t_user`.`status_data` AS `user_status_data`
FROM `t_user`
LEFT JOIN `t_user_level` ON `t_user_level`.`id` = `t_user`.`level`
WHERE `t_user`.`id` = '39'
ERROR - 2021-05-28 00:07:11 --> Query error: Unknown column 't_user.level_ib' in 'field list' - Invalid query: SELECT `t_user`.`id` AS `user_id`, `t_user`.`username` AS `user_username`, `t_user`.`password` AS `user_password`, `t_user`.`email` AS `user_email`, `t_user`.`name` AS `user_name`, `t_user`.`gender` AS `user_gender`, `t_user`.`birthday` AS `user_birthday`, `t_user`.`about` AS `user_about`, `t_user`.`address` AS `user_address`, `t_user`.`tlpn` AS `user_tlpn`, `t_user`.`id_type` AS `user_idtype`, `t_user`.`id_number` AS `user_idnumber`, `t_user`.`id_photo` AS `user_idphoto`, `t_user`.`photo` AS `user_photo`, `t_user`.`active` AS `user_active`, `t_user`.`level_ib` AS `user_level_ib`, `t_user`.`status_data` AS `user_status_data`
FROM `t_user`
LEFT JOIN `t_user_level` ON `t_user_level`.`id` = `t_user`.`level`
WHERE `t_user`.`id` = '39'
ERROR - 2021-05-28 09:05:05 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:05:14 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:05:16 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:05:21 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:05:22 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:18:22 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:18:24 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:18:29 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:18:29 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 02:19:07 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/u3110812/public_html/demoforex/application/controllers/l-member/Withdrawal.php 92
ERROR - 2021-05-28 02:19:09 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/u3110812/public_html/demoforex/application/controllers/l-member/Withdrawal.php 92
ERROR - 2021-05-28 02:19:22 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/u3110812/public_html/demoforex/application/controllers/l-member/Withdrawal.php 92
ERROR - 2021-05-28 02:19:23 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/u3110812/public_html/demoforex/application/controllers/l-member/Withdrawal.php 92
ERROR - 2021-05-28 02:19:24 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/u3110812/public_html/demoforex/application/controllers/l-member/Withdrawal.php 92
ERROR - 2021-05-28 09:20:04 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:20:07 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:21:01 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:21:05 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:21:06 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:21:10 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:24:13 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:24:14 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:24:18 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:24:49 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:24:50 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:24:55 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:24:55 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:25:00 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:25:26 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:25:27 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:25:30 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:25:30 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 02:27:40 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /home/u3110812/public_html/demoforex/application/controllers/l-member/Withdrawal.php 130
ERROR - 2021-05-28 02:27:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /home/u3110812/public_html/demoforex/application/controllers/l-member/Withdrawal.php 130
ERROR - 2021-05-28 09:28:17 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 02:28:33 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file /home/u3110812/public_html/demoforex/application/controllers/l-member/Withdrawal.php 129
ERROR - 2021-05-28 09:28:44 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:28:46 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:28:50 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:28:51 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:31:55 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:32:14 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:37:00 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:37:02 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:37:07 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 09:37:07 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 10:19:59 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 10:20:05 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 10:24:01 --> Could not find the language line "referral_title"
ERROR - 2021-05-28 10:24:16 --> Could not find the language line "referral_title"
