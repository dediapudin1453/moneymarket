<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-09 07:48:16 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\linggafx\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-05-09 07:48:16 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-05-09 07:48:16 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-05-09 12:48:16 --> Severity: Warning --> mkdir(): File exists C:\xampp\htdocs\linggafx\application\controllers\l-admin\Theme.php 331
ERROR - 2021-05-09 07:48:16 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\linggafx\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-05-09 07:48:16 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-05-09 07:48:16 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-05-09 12:48:16 --> Severity: Warning --> mkdir(): File exists C:\xampp\htdocs\linggafx\application\controllers\l-admin\Theme.php 331
ERROR - 2021-05-09 14:04:56 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\linggafx\system\libraries\Zip.php 378
