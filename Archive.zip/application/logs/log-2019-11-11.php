<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-11 13:33:41 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-11 13:33:41 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-11 13:37:55 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 21
ERROR - 2019-11-11 13:37:55 --> Severity: Notice --> Trying to get property 'picture' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 21
ERROR - 2019-11-11 13:37:55 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 23
ERROR - 2019-11-11 13:37:55 --> Severity: Notice --> Trying to get property 'picture' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 23
ERROR - 2019-11-11 13:38:40 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:38:40 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:42:29 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:42:29 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:42:46 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:42:46 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:46:30 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:46:30 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:47:34 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:47:34 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:50:20 --> Severity: Warning --> Error while sending QUERY packet. PID=457341 /home/u7014999/public_html/websitepraktis/system/database/drivers/pdo/pdo_driver.php 184
ERROR - 2019-11-11 13:50:20 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_visitor`
WHERE `ip` = '115.178.204.85'
AND `date` = '2019-11-11'
AND `url` = '/websitepraktis/content/plugins/font-awesome/css/font-awesome.min.css'
ERROR - 2019-11-11 13:50:21 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:50:21 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:53:53 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:53:53 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:55:00 --> Severity: Notice --> Undefined variable: value /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 13:55:00 --> Severity: Notice --> Trying to get property 'title' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-5/home.php 47
ERROR - 2019-11-11 14:10:49 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-11 14:10:49 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-11 14:12:43 --> Severity: Notice --> Trying to get property 'picture' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 110
ERROR - 2019-11-11 14:12:43 --> Severity: Notice --> Trying to get property 'content' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 117
ERROR - 2019-11-11 14:13:44 --> Severity: Notice --> Trying to get property 'picture' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 111
ERROR - 2019-11-11 14:13:44 --> Severity: Notice --> Trying to get property 'content' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 118
ERROR - 2019-11-11 14:14:24 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 110
ERROR - 2019-11-11 14:14:24 --> Severity: Notice --> Trying to get property 'content' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 117
ERROR - 2019-11-11 14:14:28 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 110
ERROR - 2019-11-11 14:14:28 --> Severity: Notice --> Trying to get property 'content' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 117
ERROR - 2019-11-11 14:14:54 --> Severity: Notice --> Trying to get property 'content' of non-object /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-2/home.php 117
ERROR - 2019-11-11 15:53:07 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-11-11 15:53:07 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/homepage/view_edit.php 64
ERROR - 2019-11-11 16:27:27 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:27:27 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:27:27 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:27:27 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:27:27 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:27:27 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:27:28 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:27:28 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:27:28 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:29:24 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:30:27 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:33:29 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:33:53 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:34:21 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:35:14 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:35:23 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:35:45 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:36:19 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:37:09 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:40:03 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:41:00 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:46:33 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:47:21 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:48:25 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:48:40 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 16:48:45 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:48:45 --> Could not find the language line "mod_notif_5"
ERROR - 2019-11-11 16:48:45 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:48:45 --> Could not find the language line "mod_notif_2"
ERROR - 2019-11-11 16:48:45 --> Could not find the language line "mod_notif_4"
ERROR - 2019-11-11 16:48:45 --> Could not find the language line "mod_notif_3"
ERROR - 2019-11-11 16:48:46 --> Could not find the language line "mod_welcome"
ERROR - 2019-11-11 16:48:46 --> Could not find the language line "mod_box_title_1"
ERROR - 2019-11-11 16:48:46 --> Could not find the language line "mod_box_title_3"
ERROR - 2019-11-11 17:30:15 --> 404 Page Not Found: 
ERROR - 2019-11-11 17:30:38 --> 404 Page Not Found: 
ERROR - 2019-11-11 17:31:02 --> 404 Page Not Found: 
ERROR - 2019-11-11 17:41:08 --> 404 Page Not Found: 
