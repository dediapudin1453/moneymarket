<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-18 09:48:59 --> Could not find the language line "table_content"
ERROR - 2019-11-18 09:49:02 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 09:49:02 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 09:49:02 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 09:49:02 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 09:49:02 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:49:02 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 09:49:02 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:49:08 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 09:49:08 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 09:49:08 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 09:49:08 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 09:49:08 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:49:08 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 09:49:08 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:49:14 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 09:49:14 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 09:49:14 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 09:49:14 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 09:49:14 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:49:14 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 09:49:14 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:49:18 --> Could not find the language line "table_content"
ERROR - 2019-11-18 09:56:04 --> 404 Page Not Found: 
ERROR - 2019-11-18 09:56:10 --> Could not find the language line "table_content"
ERROR - 2019-11-18 09:56:13 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 09:56:13 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 09:56:13 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 09:56:13 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 09:56:13 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:56:13 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 09:56:13 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:56:22 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 09:56:22 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 09:56:22 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 09:56:22 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 09:56:22 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:56:22 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 09:56:22 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:56:24 --> Could not find the language line "table_content"
ERROR - 2019-11-18 09:56:28 --> Could not find the language line "table_content"
ERROR - 2019-11-18 09:56:33 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 09:56:33 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 09:56:33 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 09:56:33 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 09:56:33 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:56:33 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 09:56:33 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 09:56:35 --> Could not find the language line "table_content"
ERROR - 2019-11-18 10:24:17 --> Could not find the language line "table_content"
ERROR - 2019-11-18 10:24:36 --> Could not find the language line "table_content"
ERROR - 2019-11-18 10:24:39 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 10:24:39 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 10:24:39 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 10:24:39 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 10:24:39 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 10:24:39 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 10:24:39 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 10:24:45 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 10:24:45 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 10:24:45 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 10:24:45 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 10:24:45 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 10:24:45 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 10:24:45 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 10:24:47 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 10:24:47 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 10:24:47 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 10:24:47 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 10:24:47 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 10:24:47 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 10:24:47 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 10:24:49 --> Could not find the language line "table_content"
ERROR - 2019-11-18 14:15:01 --> Could not find the language line "table_content"
ERROR - 2019-11-18 14:16:23 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 14:16:23 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 14:16:23 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 14:16:23 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 14:16:23 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 14:16:23 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 14:16:23 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 14:16:34 --> Could not find the language line "table_content"
ERROR - 2019-11-18 14:18:54 --> Could not find the language line "table_content"
ERROR - 2019-11-18 14:18:57 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 14:18:57 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 14:18:57 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 14:18:57 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 14:18:57 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 14:18:57 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 14:18:57 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 14:19:11 --> Could not find the language line "table_content"
ERROR - 2019-11-18 14:19:53 --> Could not find the language line "table_content"
ERROR - 2019-11-18 14:19:56 --> Could not find the language line "form_label_content"
ERROR - 2019-11-18 14:19:56 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 46
ERROR - 2019-11-18 14:19:56 --> Severity: Notice --> Undefined index: active /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 63
ERROR - 2019-11-18 14:19:56 --> Could not find the language line "form_label_active"
ERROR - 2019-11-18 14:19:56 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 14:19:56 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/footer/view_edit.php 89
ERROR - 2019-11-18 14:19:56 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-18 14:39:57 --> 404 Page Not Found: 
ERROR - 2019-11-18 14:41:16 --> 404 Page Not Found: 
