<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-30 08:54:25 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-04-30 08:57:09 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-04-30 09:04:36 --> Could not find the language line "table_content"
ERROR - 2020-04-30 09:07:56 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-04-30 09:15:27 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
