<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-27 02:37:41 --> Query error: Table 'u3110812_demoforex.t_setting' doesn't exist - Invalid query: SELECT `value`
FROM `t_setting`
WHERE `options` = 'timezone'
ERROR - 2021-05-27 02:37:44 --> Query error: Table 'u3110812_demoforex.t_setting' doesn't exist - Invalid query: SELECT `value`
FROM `t_setting`
WHERE `options` = 'timezone'
ERROR - 2021-05-27 10:00:09 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 10:00:15 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 10:00:17 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 10:00:18 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 10:00:47 --> Severity: Notice --> Undefined variable: data /home/u3110812/public_html/demoforex/application/controllers/l-member/Account.php 488
ERROR - 2021-05-27 10:02:03 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:33:42 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:32 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:34 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:37 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:39 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:40 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:41 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:43 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:44 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:35:46 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:38:28 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:38:28 --> Severity: Notice --> Undefined index: status_data /home/u3110812/public_html/demoforex/application/controllers/l-member/Payments.php 28
ERROR - 2021-05-27 23:39:10 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:39:12 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:39:12 --> Could not find the language line "account_incomplete"
ERROR - 2021-05-27 23:39:12 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:41:21 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:41:21 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:42:36 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:42:38 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:42:39 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:42:40 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:42:57 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:43:01 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:43:02 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:48:17 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:48:19 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:48:19 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:48:23 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:48:25 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:48:25 --> Severity: error --> Exception: Call to undefined method Account_model::get_wallet_history() /home/u3110812/public_html/demoforex/application/controllers/l-member/Account_trading.php 80
ERROR - 2021-05-27 23:53:00 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:00 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:04 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:04 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:15 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:16 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:16 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:22 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:23 --> Could not find the language line "referral_title"
ERROR - 2021-05-27 23:53:23 --> Could not find the language line "referral_title"
