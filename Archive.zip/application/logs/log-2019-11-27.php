<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-27 07:38:27 --> Could not find the language line "form_label_content"
ERROR - 2019-11-27 07:38:27 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:38:27 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:38:53 --> Could not find the language line "form_label_content"
ERROR - 2019-11-27 07:38:53 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:38:53 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:53:40 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:53:40 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:53:59 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:53:59 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:54:23 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 07:54:23 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 00:57:57 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 132
ERROR - 2019-11-27 08:05:30 --> Severity: error --> Exception: Unsupported operand types /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 129
ERROR - 2019-11-27 08:06:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `active`) VALUES ('Test', '0', 'test', '4', 6, 'Y')' at line 1 - Invalid query: INSERT INTO `t_menu` (`title`, `parent_id`, `url`, `group_id`, , `active`) VALUES ('Test', '0', 'test', '4', 6, 'Y')
ERROR - 2019-11-27 08:14:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `active`) VALUES ('test', '0', 'test', '4', 6, 'Y')' at line 1 - Invalid query: INSERT INTO `t_menu` (`title`, `parent_id`, `url`, `group_id`, , `active`) VALUES ('test', '0', 'test', '4', 6, 'Y')
ERROR - 2019-11-27 08:16:23 --> Severity: Notice --> Undefined index: seotitle /home/u7014999/public_html/websitepraktis/application/views/mod/menuwebsite/view_edit.php 35
ERROR - 2019-11-27 08:16:23 --> Could not find the language line "form_label_content"
ERROR - 2019-11-27 08:16:23 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/menuwebsite/view_edit.php 47
ERROR - 2019-11-27 08:16:23 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 08:16:23 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/menuwebsite/view_edit.php 90
ERROR - 2019-11-27 08:16:23 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 08:17:03 --> Could not find the language line "form_label_content"
ERROR - 2019-11-27 08:17:03 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/menuwebsite/view_edit.php 46
ERROR - 2019-11-27 08:17:03 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 08:17:03 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/menuwebsite/view_edit.php 89
ERROR - 2019-11-27 08:17:03 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 08:40:11 --> Could not find the language line "form_label_content"
ERROR - 2019-11-27 08:40:11 --> Severity: Notice --> Undefined index: content /home/u7014999/public_html/websitepraktis/application/views/mod/menuwebsite/view_edit.php 60
ERROR - 2019-11-27 08:40:11 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 08:40:11 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/menuwebsite/view_edit.php 103
ERROR - 2019-11-27 08:40:11 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 08:41:18 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 08:41:18 --> Severity: Notice --> Undefined index: picture /home/u7014999/public_html/websitepraktis/application/views/mod/menuwebsite/view_edit.php 94
ERROR - 2019-11-27 08:41:18 --> Could not find the language line "form_label_picture"
ERROR - 2019-11-27 08:41:42 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_menu`
WHERE `seotitle` = ''
ERROR - 2019-11-27 08:41:44 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_menu`
WHERE `seotitle` = ''
ERROR - 2019-11-27 08:42:54 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:42:55 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:42:55 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:42:56 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:42:56 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:42:56 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:42:56 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:07 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:08 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:22 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:22 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:29 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:30 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:31 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:31 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:31 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:31 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:31 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:43:31 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:17 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:19 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:19 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:19 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:19 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:19 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:20 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:20 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:20 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:21 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:21 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:21 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:44:25 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 08:46:57 --> Severity: Notice --> Undefined variable: data /home/u7014999/public_html/websitepraktis/application/controllers/l-admin/Menuwebsite.php 237
ERROR - 2019-11-27 17:35:53 --> Severity: Notice --> Undefined property: stdClass::$subtitle /home/u7014999/public_html/websitepraktis/application/views/themes/profile-bisnis-1/home.php 27
