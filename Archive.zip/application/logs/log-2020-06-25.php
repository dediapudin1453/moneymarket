<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-25 09:50:19 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 09:50:19 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-06-25 09:50:19 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-06-25 09:50:19 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-06-25 09:50:32 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 09:50:33 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 09:54:53 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 09:55:08 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 09:55:16 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 10:36:26 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:05 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:05 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-06-25 12:49:05 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-06-25 12:49:05 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-06-25 12:49:10 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:12 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:16 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:18 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:23 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:26 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:33 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:37 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:43 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:56 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:49:56 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-06-25 12:49:56 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-06-25 12:49:56 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-06-25 12:50:03 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:50:04 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:51:45 --> Could not find the language line "form_label_title"
ERROR - 2020-06-25 12:53:20 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:54:19 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:54:29 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:54:30 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 12:56:17 --> Could not find the language line "form_label_title"
ERROR - 2020-06-25 12:57:27 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:02:59 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:03:01 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:03:30 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:03:32 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:03:59 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:03:59 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:04:22 --> Could not find the language line "form_label_title"
ERROR - 2020-06-25 13:04:22 --> Query error: Column 'wallet_id' cannot be null - Invalid query: INSERT INTO `t_wallet_history` (`wallet_id`, `amount_before`, `amount`, `amount_after`, `source`, `deposit_id`) VALUES (NULL, NULL, '694.44', 694.44, 'Deposit', 9)
ERROR - 2020-06-25 13:04:27 --> Could not find the language line "form_label_title"
ERROR - 2020-06-25 13:04:34 --> Could not find the language line "form_label_title"
ERROR - 2020-06-25 13:08:11 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:08:19 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:08:26 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 13:08:26 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 22:16:31 --> Could not find the language line "referral_title"
ERROR - 2020-06-25 22:28:27 --> Could not find the language line "referral_title"
