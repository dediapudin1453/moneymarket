<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\linggafx\system\core\Exceptions.php:271) C:\xampp\htdocs\linggafx\system\core\Common.php 570
ERROR - 2021-05-02 10:00:29 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:29 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:29 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:29 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:29 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:29 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:30 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:30 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:30 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:30 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 49
ERROR - 2021-05-02 10:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\linggafx\system\core\Exceptions.php:271) C:\xampp\htdocs\linggafx\system\core\Common.php 570
ERROR - 2021-05-02 05:08:43 --> Severity: error --> Exception: syntax error, unexpected '==' (T_IS_EQUAL) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 51
ERROR - 2021-05-02 05:29:25 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 74
ERROR - 2021-05-02 05:32:41 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 76
ERROR - 2021-05-02 05:32:43 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 76
ERROR - 2021-05-02 05:42:59 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 55
ERROR - 2021-05-02 05:43:18 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 55
ERROR - 2021-05-02 05:43:19 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 55
ERROR - 2021-05-02 05:43:20 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 55
ERROR - 2021-05-02 05:43:20 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 55
ERROR - 2021-05-02 05:44:23 --> Severity: error --> Exception: syntax error, unexpected '$val' (T_VARIABLE) C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 54
ERROR - 2021-05-02 11:47:41 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 41
ERROR - 2021-05-02 11:47:42 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\linggafx\application\controllers\l-admin\Deposit.php 41
