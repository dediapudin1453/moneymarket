<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-24 08:09:31 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 09:10:29 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 09:11:32 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 09:11:46 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 09:11:52 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 09:13:53 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 10:36:11 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 10:36:17 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 10:36:41 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 10:36:51 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 10:36:59 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 11:18:39 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 11:19:04 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 11:19:18 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 11:19:46 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 11:31:13 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 11:31:13 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 11:31:13 --> Could not find the language line "referral_title"
ERROR - 2021-02-24 22:31:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\kalingga\application\controllers\l-member\Account.php 475
ERROR - 2021-02-24 22:33:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\kalingga\application\controllers\l-member\Account.php 475
ERROR - 2021-02-24 22:33:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\kalingga\application\controllers\l-member\Account.php 475
ERROR - 2021-02-24 22:33:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\kalingga\application\controllers\l-member\Account.php 475
