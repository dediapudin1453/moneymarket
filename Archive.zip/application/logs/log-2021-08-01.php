<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-01 08:46:11 --> Query error: Unknown column 'level_ib' in 'field list' - Invalid query: SELECT `username`, `email`, `name`, `gender`, `birthday`, `about`, `address`, `tlpn`, `photo`, `id_type`, `id_number`, `id_photo`, `level_ib`, `status_data`
FROM `t_user`
WHERE `id` = '9'
ERROR - 2021-08-01 08:46:51 --> Severity: Notice --> Undefined index: join_date /home/u1476998/public_html/demoforex/application/views/member/account.php 29
ERROR - 2021-08-01 08:46:51 --> Severity: Notice --> Undefined index: join_date /home/u1476998/public_html/demoforex/application/views/member/account.php 32
ERROR - 2021-08-01 08:47:44 --> Severity: Notice --> Undefined index: join_date /home/u1476998/public_html/demoforex/application/views/member/account.php 29
ERROR - 2021-08-01 08:47:44 --> Severity: Notice --> Undefined index: join_date /home/u1476998/public_html/demoforex/application/views/member/account.php 32
ERROR - 2021-08-01 12:51:35 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/controllers/l-member/Login.php 436
