<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-01 13:50:20 --> Severity: Compile Error --> Cannot redeclare Home::setlang() /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 124
ERROR - 2019-12-01 13:52:11 --> Severity: Compile Error --> Cannot redeclare Home::setlang() /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 124
ERROR - 2019-12-01 21:08:25 --> Could not find the language line "form_validation_required|trim|max_length15]"
ERROR - 2019-12-01 21:08:50 --> Severity: Notice --> Undefined property: Home::$email /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 208
ERROR - 2019-12-01 21:08:50 --> Severity: error --> Exception: Call to a member function initialize() on null /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 208
ERROR - 2019-12-01 21:14:19 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 226
ERROR - 2019-12-01 21:22:37 --> Severity: Notice --> Undefined property: Test::$email /home/u7014999/public_html/websitepraktis/application/controllers/Test.php 39
ERROR - 2019-12-01 21:22:37 --> Severity: error --> Exception: Call to a member function initialize() on null /home/u7014999/public_html/websitepraktis/application/controllers/Test.php 39
ERROR - 2019-12-01 21:45:53 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 228
ERROR - 2019-12-01 21:48:19 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 228
ERROR - 2019-12-01 21:55:26 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 228
ERROR - 2019-12-01 21:57:40 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 228
ERROR - 2019-12-01 21:58:18 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 228
ERROR - 2019-12-01 22:02:32 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 228
ERROR - 2019-12-01 22:03:36 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 228
ERROR - 2019-12-01 22:05:55 --> Severity: Notice --> Undefined variable: full_name /home/u7014999/public_html/websitepraktis/application/controllers/Home.php 228
