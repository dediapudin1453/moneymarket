<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-10 21:23:50 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-10 21:24:01 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-10 21:26:53 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-10 21:26:53 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-10 21:28:05 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-10 21:28:18 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-10 22:20:40 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:21:03 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:23:50 --> Could not find the language line "table_content"
ERROR - 2020-05-10 22:23:55 --> Could not find the language line "form_label_content"
ERROR - 2020-05-10 22:23:55 --> Severity: Notice --> Undefined index: content /home/qx59rn1k06vg/public_html/application/views/mod/footer/view_edit.php 48
ERROR - 2020-05-10 22:23:55 --> Severity: Notice --> Undefined index: active /home/qx59rn1k06vg/public_html/application/views/mod/footer/view_edit.php 65
ERROR - 2020-05-10 22:23:55 --> Could not find the language line "form_label_active"
ERROR - 2020-05-10 22:23:55 --> Could not find the language line "form_label_picture"
ERROR - 2020-05-10 22:23:55 --> Severity: Notice --> Undefined index: picture /home/qx59rn1k06vg/public_html/application/views/mod/footer/view_edit.php 91
ERROR - 2020-05-10 22:23:55 --> Could not find the language line "form_label_picture"
ERROR - 2020-05-10 22:26:19 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:26:42 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:28:06 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/landingpage/view_edit.php 35
ERROR - 2020-05-10 22:38:22 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:39:06 --> Could not find the language line "table_content"
ERROR - 2020-05-10 22:39:10 --> Could not find the language line "form_label_content"
ERROR - 2020-05-10 22:39:10 --> Severity: Notice --> Undefined index: content /home/qx59rn1k06vg/public_html/application/views/mod/footer/view_edit.php 48
ERROR - 2020-05-10 22:39:10 --> Severity: Notice --> Undefined index: active /home/qx59rn1k06vg/public_html/application/views/mod/footer/view_edit.php 65
ERROR - 2020-05-10 22:39:10 --> Could not find the language line "form_label_active"
ERROR - 2020-05-10 22:39:10 --> Could not find the language line "form_label_picture"
ERROR - 2020-05-10 22:39:10 --> Severity: Notice --> Undefined index: picture /home/qx59rn1k06vg/public_html/application/views/mod/footer/view_edit.php 91
ERROR - 2020-05-10 22:39:10 --> Could not find the language line "form_label_picture"
ERROR - 2020-05-10 22:40:17 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:40:27 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:40:38 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:40:47 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-10 22:41:54 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
