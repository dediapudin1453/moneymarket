<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-24 06:50:14 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 06:57:58 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 06:58:17 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 07:02:59 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/landingpage/view_edit.php 35
ERROR - 2021-01-24 07:04:18 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/landingpage/view_edit.php 35
ERROR - 2021-01-24 07:05:00 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 07:05:33 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 07:06:15 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 07:16:37 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 07:16:59 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 07:47:33 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 07:53:45 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 07:53:57 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 08:04:19 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 08:09:06 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 08:09:29 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 08:10:27 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT *
FROM `t_homepage`
WHERE `jenis` = 'bagian2'
AND `status` = 'Y'
ERROR - 2021-01-24 08:20:55 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 08:21:39 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 08:22:33 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 08:28:16 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 10:12:52 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 10:40:18 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 10:45:08 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 10:46:01 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 10:46:51 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 10:49:05 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 10:50:45 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 10:53:06 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 10:53:38 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 10:56:44 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 10:57:02 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 10:57:05 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 10:57:24 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 10:57:51 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 11:00:03 --> Severity: Notice --> Undefined variable: res_headline /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/post.php 29
ERROR - 2021-01-24 11:00:03 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 11:00:20 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 11:00:25 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 11:00:42 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 11:03:29 --> Query error: Column 'referral_id' cannot be null - Invalid query: INSERT INTO `t_user` (`name`, `username`, `email`, `password`, `photo`, `level`, `active`, `activation_key`, `referral_id`) VALUES ('Gebrine', 'gebrine', 'Gebrine@gmail.com', '67d3b27b1ff9f1234483fe7eb503a1565bcf22f26407e0b8058cee6fb2d2fa427bc17cfb215e04e224bbc6544ef93468d1bd67183d72ba408599829bea9c0ed9qPFjKzY4PJ9IZHWygO5XMZ62Utn0gvVp52dMCUrqwx4=', 'user-951088e321d32555fbc40602774f718b.jpg', '4', 'Y', '29f7fb885d940f611de6716f6bb9827f', NULL)
ERROR - 2021-01-24 11:05:22 --> Query error: Column 'referral_id' cannot be null - Invalid query: INSERT INTO `t_user` (`name`, `username`, `email`, `password`, `photo`, `level`, `active`, `activation_key`, `referral_id`) VALUES ('Didin', 'kalongfx', 'erwanadenfx@gmail.com', '891a2eb8dc6a5b2b24168b3ae10fd85cd7250e0f4ea91435deb67d6e1650cf6ad4801b9435ded87450df95c1e04b199c96ae201b834839e87d4cfa2601806d57GYr98aGJOPbR1P9v59Ga5bQMsu/ZaCej0C8cPe+IRpA=', 'user-f669688b106e7ae1dca8f2553ee75405.jpg', '4', 'Y', '67a2f3c5b3507861fe2f90d11ce2b600', NULL)
ERROR - 2021-01-24 11:05:44 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 11:06:01 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 11:06:14 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 11:06:16 --> Severity: Notice --> Undefined variable: titlecta /home/kqw5yzwxdlcw/public_html/application/views/themes/wwforexco-a4dfdfc73416cc978925ca4bc8352877/footer.php 8
ERROR - 2021-01-24 11:06:53 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 11:11:59 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 11:14:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 11:18:34 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 11:33:20 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 14:08:44 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 14:18:48 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 14:55:09 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 14:56:59 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 17:32:58 --> Could not find the language line "table_title"
ERROR - 2021-01-24 17:32:58 --> Could not find the language line "table_content"
ERROR - 2021-01-24 17:33:08 --> Could not find the language line "form_label_content"
ERROR - 2021-01-24 17:33:08 --> Severity: Notice --> Undefined index: content /home/kqw5yzwxdlcw/public_html/application/views/mod/footer/view_edit.php 48
ERROR - 2021-01-24 17:33:08 --> Severity: Notice --> Undefined index: active /home/kqw5yzwxdlcw/public_html/application/views/mod/footer/view_edit.php 65
ERROR - 2021-01-24 17:33:08 --> Could not find the language line "form_label_active"
ERROR - 2021-01-24 17:33:08 --> Could not find the language line "form_label_picture"
ERROR - 2021-01-24 17:33:08 --> Severity: Notice --> Undefined index: picture /home/kqw5yzwxdlcw/public_html/application/views/mod/footer/view_edit.php 91
ERROR - 2021-01-24 17:33:08 --> Could not find the language line "form_label_picture"
ERROR - 2021-01-24 17:34:26 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-24 17:46:48 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 17:49:51 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 20:47:11 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 20:47:21 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 20:47:32 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 20:47:41 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 20:47:42 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 21:26:51 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 21:26:53 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 21:27:00 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 21:27:11 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 21:27:52 --> Could not find the language line "referral_title"
ERROR - 2021-01-24 21:28:15 --> Could not find the language line "referral_title"
