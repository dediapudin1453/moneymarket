<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-01-22 14:05:48 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 16:06:48 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 16:06:49 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 16:08:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 16:08:25 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 16:08:27 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 16:08:28 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:50:10 --> Severity: Notice --> Undefined variable: data /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/controllers/l-member/Account.php 475
ERROR - 2021-01-22 17:51:26 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:51:37 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:52:30 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:52:30 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:53:37 --> Could not find the language line "form_label_title"
ERROR - 2021-01-22 17:54:08 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:54:30 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:54:33 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:55:03 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:55:03 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 121
ERROR - 2021-01-22 17:55:03 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 132
ERROR - 2021-01-22 17:55:03 --> Severity: Notice --> Undefined variable: res /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/member/account_trading.php 138
ERROR - 2021-01-22 17:56:12 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:56:13 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 17:56:54 --> Severity: Notice --> Undefined offset: 5 /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/models/mod/Account_trading_model.php 48
ERROR - 2021-01-22 17:56:54 --> Severity: Notice --> Undefined offset: 5 /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/models/mod/Account_trading_model.php 48
ERROR - 2021-01-22 17:57:29 --> Could not find the language line "form_label_title"
ERROR - 2021-01-22 17:59:04 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 18:00:34 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 18:04:03 --> Could not find the language line "form_label_title"
ERROR - 2021-01-22 18:12:15 --> Could not find the language line "table_title"
ERROR - 2021-01-22 18:12:15 --> Could not find the language line "table_content"
ERROR - 2021-01-22 18:12:21 --> Could not find the language line "form_label_content"
ERROR - 2021-01-22 18:12:21 --> Severity: Notice --> Undefined index: content /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/mod/footer/view_edit.php 48
ERROR - 2021-01-22 18:12:21 --> Severity: Notice --> Undefined index: active /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/mod/footer/view_edit.php 65
ERROR - 2021-01-22 18:12:21 --> Could not find the language line "form_label_active"
ERROR - 2021-01-22 18:12:21 --> Could not find the language line "form_label_picture"
ERROR - 2021-01-22 18:12:21 --> Severity: Notice --> Undefined index: picture /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/mod/footer/view_edit.php 91
ERROR - 2021-01-22 18:12:21 --> Could not find the language line "form_label_picture"
ERROR - 2021-01-22 18:13:50 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-22 18:14:00 --> Severity: Notice --> Undefined index: seotitle /home/kqw5yzwxdlcw/public_html/dev.wwforex.co/application/views/mod/homepage/view_edit.php 35
ERROR - 2021-01-22 18:18:03 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 18:18:04 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 18:19:41 --> Could not find the language line "referral_title"
ERROR - 2021-01-22 18:19:43 --> Could not find the language line "referral_title"
