<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-25 12:00:13 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\linggafx\system\database\drivers\pdo\pdo_driver.php 136
