<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-30 09:00:39 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\websitepraktis\application\views\mod\homepage\view_edit.php 35
ERROR - 2019-10-30 09:00:39 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\websitepraktis\application\views\mod\homepage\view_edit.php 64
ERROR - 2019-10-30 09:11:29 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\websitepraktis\application\views\mod\homepage\view_edit.php 35
ERROR - 2019-10-30 09:11:29 --> Severity: Notice --> Undefined index: active C:\xampp\htdocs\websitepraktis\application\views\mod\homepage\view_edit.php 64
ERROR - 2019-10-30 14:29:03 --> 404 Page Not Found: 
ERROR - 2019-10-30 14:29:05 --> 404 Page Not Found: 
ERROR - 2019-10-30 14:29:06 --> 404 Page Not Found: 
ERROR - 2019-10-30 14:29:07 --> 404 Page Not Found: 
ERROR - 2019-10-30 14:29:07 --> 404 Page Not Found: 
