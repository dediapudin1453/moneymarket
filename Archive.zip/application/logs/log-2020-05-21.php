<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-21 16:45:11 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-21 16:45:22 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-21 16:52:02 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-21 17:01:08 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:01:12 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:01:53 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:01:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:02:00 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:02:02 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:03:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:03:16 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:08:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:08:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:08:34 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:08:35 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:08:36 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:08:38 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 17:08:38 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-05-21 17:08:38 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-05-21 17:08:38 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-05-21 17:08:40 --> Could not find the language line "referral_title"
ERROR - 2020-05-21 18:29:02 --> Could not find the language line "referral_title"
