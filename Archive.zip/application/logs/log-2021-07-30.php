<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-30 12:52:24 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/header.php 121
ERROR - 2021-07-30 12:52:24 --> Severity: Notice --> Undefined variable: titlecta /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-07-30 12:52:24 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-07-30 16:53:25 --> Could not find the language line "referral_title"
ERROR - 2021-07-30 16:53:32 --> Could not find the language line "referral_title"
ERROR - 2021-07-30 16:53:41 --> Could not find the language line "referral_title"
ERROR - 2021-07-30 16:53:43 --> Could not find the language line "referral_title"
ERROR - 2021-07-30 16:53:45 --> Could not find the language line "referral_title"
