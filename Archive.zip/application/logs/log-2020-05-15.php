<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-15 10:37:07 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 12:57:44 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 12:58:47 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 12:58:49 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 12:58:51 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 12:58:52 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 13:11:15 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 13:23:11 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 16:49:54 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 22:57:17 --> Severity: error --> Exception: syntax error, unexpected '$i' (T_VARIABLE) /home/qx59rn1k06vg/public_html/application/models/mod/Add_account_receiver_model.php 24
ERROR - 2020-05-15 22:57:29 --> Query error: Unknown column 't_account_receiver.account_id' in 'where clause' - Invalid query: SELECT *, `t_account_trading`.`id` as `id`
FROM `t_account_trading`
JOIN `t_user` ON `t_user`.`id`=`t_account_trading`.`user_id`
WHERE `t_account_trading`.`id` != `t_account_receiver`.`account_id`
ORDER BY `t_account_trading`.`id` DESC
 LIMIT 10
ERROR - 2020-05-15 15:57:47 --> Severity: error --> Exception: syntax error, unexpected 'foreach' (T_FOREACH) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Add_account_receiver.php 29
ERROR - 2020-05-15 22:58:01 --> Query error: Unknown column 't_account_receiver.account_id' in 'where clause' - Invalid query: SELECT *, `t_account_trading`.`id` as `id`
FROM `t_account_trading`
JOIN `t_user` ON `t_user`.`id`=`t_account_trading`.`user_id`
WHERE `t_account_trading`.`id` != `t_account_receiver`.`account_id`
ORDER BY `t_account_trading`.`id` DESC
ERROR - 2020-05-15 23:34:32 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 23:34:48 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 23:34:48 --> Could not find the language line "referral_title"
ERROR - 2020-05-15 22:27:25 --> Severity: error --> Exception: syntax error, unexpected '$cek' (T_VARIABLE) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 85
ERROR - 2020-05-15 22:27:28 --> Severity: error --> Exception: syntax error, unexpected '$cek' (T_VARIABLE) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 85
ERROR - 2020-05-15 22:28:58 --> Severity: error --> Exception: syntax error, unexpected '$cekAcc' (T_VARIABLE) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 85
ERROR - 2020-05-15 22:30:13 --> Severity: error --> Exception: syntax error, unexpected '$cekAcc' (T_VARIABLE) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 85
ERROR - 2020-05-15 22:30:14 --> Severity: error --> Exception: syntax error, unexpected '$cekAcc' (T_VARIABLE) /home/qx59rn1k06vg/public_html/application/controllers/l-admin/Account_receiver.php 85
