<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-17 21:41:52 --> Severity: Notice --> Undefined variable: cek_url /home/u3110812/public_html/kalingga/application/views/themes/kalingga-def3faa51d697def1e6355c1487c0ee6/header.php 75
