<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-05 16:47:21 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-14/application/views/mod/homepage/view_edit.php 35
