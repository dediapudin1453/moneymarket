<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-08 01:08:16 --> Could not find the language line "referral_title"
ERROR - 2021-02-08 01:08:18 --> Could not find the language line "referral_title"
ERROR - 2021-02-08 01:08:22 --> Could not find the language line "referral_title"
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 102
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 01:23:08 --> Severity: Notice --> Undefined index: content C:\xampp\htdocs\linggafx\application\views\themes\landingpage-1-90af362d24895773da7fb4572990adb2\home.php 134
ERROR - 2021-02-08 02:14:31 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-02-08 02:14:52 --> Severity: Notice --> Undefined index: seotitle C:\xampp\htdocs\linggafx\application\views\mod\homepage\view_edit.php 35
ERROR - 2021-02-08 09:36:04 --> Severity: Notice --> Undefined index: titile C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:36:04 --> Severity: Notice --> Undefined index: titile C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:36:04 --> Severity: Notice --> Undefined index: titile C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:36:41 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:36:41 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:36:41 --> Severity: Notice --> Undefined index: title C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:39:05 --> Severity: Notice --> Undefined index: titile C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:39:05 --> Severity: Notice --> Undefined index: titile C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:39:05 --> Severity: Notice --> Undefined index: titile C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:39:47 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:39:54 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:40:26 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:42:10 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:42:31 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:50:34 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:50:39 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 130
ERROR - 2021-02-08 09:51:00 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 125
ERROR - 2021-02-08 09:51:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 125
ERROR - 2021-02-08 10:08:01 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 133
ERROR - 2021-02-08 10:08:55 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 134
ERROR - 2021-02-08 10:08:58 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 134
ERROR - 2021-02-08 10:11:31 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 133
ERROR - 2021-02-08 10:11:39 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\linggafx\application\views\themes\linggafx-d63521b73e0da66c0061cb8d65080504\home.php 133
ERROR - 2021-02-08 08:51:37 --> Query error: Table 'u3110812_linggafx.t_setting' doesn't exist - Invalid query: SELECT `value`
FROM `t_setting`
WHERE `options` = 'timezone'
ERROR - 2021-02-08 08:51:50 --> Query error: Table 'u3110812_linggafx.t_setting' doesn't exist - Invalid query: SELECT `value`
FROM `t_setting`
WHERE `options` = 'timezone'
ERROR - 2021-02-08 16:04:11 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 17
ERROR - 2021-02-08 16:04:13 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 17
ERROR - 2021-02-08 16:04:30 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 18
ERROR - 2021-02-08 16:04:32 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 18
ERROR - 2021-02-08 16:07:22 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 18
ERROR - 2021-02-08 16:07:47 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 18
ERROR - 2021-02-08 16:08:05 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 18
ERROR - 2021-02-08 16:08:25 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 18
ERROR - 2021-02-08 16:09:13 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 19
ERROR - 2021-02-08 16:09:40 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 19
ERROR - 2021-02-08 16:10:01 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 19
ERROR - 2021-02-08 16:10:46 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 19
ERROR - 2021-02-08 16:11:13 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 19
ERROR - 2021-02-08 16:11:14 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 19
ERROR - 2021-02-08 16:11:47 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:12:12 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:12:18 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:13:43 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:13:46 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:13:48 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:14:04 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:14:20 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:14:48 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:15:33 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
ERROR - 2021-02-08 16:15:36 --> Severity: error --> Exception: Call to undefined method Login::theme_asset() /home/u3110812/public_html/linggafx/application/views/member/log_signin.php 35
