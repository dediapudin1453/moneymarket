<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Footer';
$lang['mod_title_all'] = 'All Footer';
$lang['mod_title_add'] = 'Add New Footer';
$lang['mod_title_edit'] = 'Update Footer';
$lang['table_id'] = 'Id';
$lang['table_copyright'] = 'Type';
$lang['table_copyright'] = 'Copyright';
$lang['table_active'] = 'Active';
$lang['table_action'] = 'Action';
$lang['form_label_copyright'] = 'Copyright';
$lang['form_message_add_success'] = 'Data Footer has been successfully added';
$lang['form_message_update_success'] = 'Data Footer has been successfully updated';
$lang['form_message_delete_success'] = 'Data Footer has been successfully deleted';