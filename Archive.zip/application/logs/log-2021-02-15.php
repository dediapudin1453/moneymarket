<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-15 16:42:52 --> Query error: Table 'u3110812_linggaforex.t_step_registrasi' doesn't exist - Invalid query: SELECT *
FROM `t_step_registrasi`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2021-02-15 16:47:13 --> Query error: Table 'u3110812_linggaforex.t_step_registrasi' doesn't exist - Invalid query: SELECT *
FROM `t_step_registrasi`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2021-02-15 16:47:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:47:32 --> Query error: Table 'u3110812_linggaforex.t_step_registrasi' doesn't exist - Invalid query: SELECT *
FROM `t_step_registrasi`
ORDER BY `id` DESC
ERROR - 2021-02-15 16:47:53 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:47:53 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:48:24 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:48:24 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:48:25 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:48:25 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:49:06 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:49:06 --> Severity: Notice --> Trying to access array offset on value of type null /home/u3110812/public_html/kalingga/application/models/mod/Step_registrasi_model.php 23
ERROR - 2021-02-15 16:56:41 --> Query error: Unknown column 'seotitle' in 'where clause' - Invalid query: SELECT *
FROM `t_step_register`
WHERE `seotitle` = '4'
ERROR - 2021-02-15 16:56:49 --> Query error: Unknown column 'seotitle' in 'where clause' - Invalid query: SELECT *
FROM `t_step_register`
WHERE `seotitle` = '4'
ERROR - 2021-02-15 16:59:53 --> Severity: Notice --> Undefined index: seotitle /home/u3110812/public_html/kalingga/application/views/mod/step_registrasi/view_edit.php 35
ERROR - 2021-02-15 16:59:53 --> Severity: Notice --> Undefined index: leverage /home/u3110812/public_html/kalingga/application/views/mod/step_registrasi/view_edit.php 40
ERROR - 2021-02-15 16:59:53 --> Severity: Notice --> Undefined index: content /home/u3110812/public_html/kalingga/application/views/mod/step_registrasi/view_edit.php 51
ERROR - 2021-02-15 16:59:53 --> Severity: Notice --> Undefined index: active /home/u3110812/public_html/kalingga/application/views/mod/step_registrasi/view_edit.php 68
ERROR - 2021-02-15 16:59:53 --> Severity: Notice --> Undefined index: picture /home/u3110812/public_html/kalingga/application/views/mod/step_registrasi/view_edit.php 94
ERROR - 2021-02-15 17:01:02 --> Severity: Notice --> Undefined index: content /home/u3110812/public_html/kalingga/application/views/mod/step_registrasi/view_edit.php 50
ERROR - 2021-02-15 17:01:48 --> Query error: Unknown column 'seotitle' in 'where clause' - Invalid query: SELECT *
FROM `t_step_register`
WHERE `seotitle` = '4'
ERROR - 2021-02-15 17:06:14 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:06:15 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:06:16 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:06:16 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:06:16 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:06:16 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:06:17 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:14:26 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:18:04 --> Query error: Unknown column 'seotitle' in 'field list' - Invalid query: SELECT `id`, `seotitle`
FROM `t_step_register`
WHERE `seotitle` = '3'
ERROR - 2021-02-15 17:24:44 --> Severity: Notice --> Undefined variable: pk /home/u3110812/public_html/kalingga/application/controllers/l-admin/Step_registrasi.php 171
ERROR - 2021-02-15 17:25:26 --> Query error: Unknown column 'seotitle' in 'where clause' - Invalid query: SELECT *
FROM `t_step_register`
WHERE `seotitle` = '4'
