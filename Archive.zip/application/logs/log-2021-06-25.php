<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-25 22:38:12 --> Severity: Notice --> getimagesize(): read of 8192 bytes failed with errno=21 Is a directory /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-06-25 22:38:12 --> Severity: Notice --> getimagesize(): Read error! /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 122
ERROR - 2021-06-25 22:38:12 --> Severity: error --> Exception: Invalid image file: content/uploads/user/ /home/u1476998/public_html/demoforex/application/libraries/Simple_image.php 124
