<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-23 11:37:11 --> Could not find the language line "referral_title"
ERROR - 2021-02-23 16:53:59 --> Query error: Table 'kalingga.t_step_register' doesn't exist - Invalid query: SELECT *
FROM `t_step_register`
ERROR - 2021-02-23 13:20:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:20:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:21:00 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:21:00 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:21:00 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:21:00 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:21:00 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:21:00 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:21:00 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:21:00 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:21:00 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:53:34 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:53:34 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:53:34 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:53:34 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:53:34 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:53:34 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:53:34 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:53:34 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:53:34 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:59:49 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:59:49 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:59:49 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:59:49 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:59:50 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:59:50 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:59:50 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:59:50 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:59:50 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:59:50 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:59:50 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:59:50 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
ERROR - 2021-02-23 13:59:50 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\kalingga\system\libraries\Session\drivers\Session_files_driver.php 182
ERROR - 2021-02-23 13:59:50 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-02-23 13:59:50 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
