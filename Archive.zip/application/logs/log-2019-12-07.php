<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-07 05:24:28 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-12/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-07 05:30:05 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-12/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-07 06:13:19 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-13/application/views/mod/homepage/view_edit.php 35
