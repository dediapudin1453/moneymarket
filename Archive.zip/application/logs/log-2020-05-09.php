<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-09 04:24:15 --> Severity: Notice --> Undefined variable: footer /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 6
ERROR - 2020-05-09 04:24:18 --> Severity: Notice --> Undefined variable: footer /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 6
ERROR - 2020-05-09 04:24:53 --> Severity: Notice --> Undefined variable: footer /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 6
ERROR - 2020-05-09 05:16:08 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-09 05:38:31 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-09 05:45:43 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-09 07:11:32 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-09 07:13:23 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-09 07:15:11 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-09 08:36:51 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-09 08:37:42 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-09 08:39:24 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-09 08:44:30 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-09 08:49:21 --> Severity: Warning --> fsockopen(): unable to connect to http://rexchangermarkets.com/:465 (Unable to find the socket transport &quot;http&quot; - did you forget to enable it when you configured PHP?) /home/qx59rn1k06vg/public_html/system/libraries/Email.php 2069
ERROR - 2020-05-09 13:07:38 --> Severity: Notice --> Undefined index: seotitle /home/qx59rn1k06vg/public_html/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-05-09 21:46:03 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-09 21:46:15 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
ERROR - 2020-05-09 21:46:22 --> Severity: Notice --> Undefined variable: titlecta /home/qx59rn1k06vg/public_html/application/views/themes/profile-bisnis-9-47580349102b8d59c78ed0d0e3c858ab/footer.php 8
