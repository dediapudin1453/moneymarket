<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-24 13:15:34 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:15:34 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:15:58 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:16:13 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:17:51 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:17:59 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:18:00 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:18:13 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:18:19 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:18:19 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-06-24 13:18:19 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-06-24 13:18:19 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-06-24 13:18:25 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:19:08 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:19:08 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 121
ERROR - 2020-06-24 13:19:08 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 132
ERROR - 2020-06-24 13:19:08 --> Severity: Notice --> Undefined variable: res /home/qx59rn1k06vg/public_html/application/views/member/account_trading.php 138
ERROR - 2020-06-24 13:24:45 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:24:52 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:29:25 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:29:31 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:38:04 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:38:07 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:39:24 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 13:39:24 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 14:47:32 --> Could not find the language line "form_label_title"
ERROR - 2020-06-24 14:58:07 --> Could not find the language line "referral_title"
ERROR - 2020-06-24 14:58:07 --> Could not find the language line "referral_title"
