<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-02 15:06:30 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-8/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-02 15:46:16 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-8/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-02 15:47:01 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-8/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-02 15:55:14 --> Severity: Warning --> Error while sending QUERY packet. PID=1901787 /home/u8936188/public_html/demo-profile-bisnis-8/system/database/drivers/pdo/pdo_driver.php 184
ERROR - 2019-12-02 15:55:14 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_visitor`
WHERE `ip` = '115.178.207.183'
AND `date` = '2019-12-02'
AND `url` = '/demo-profile-bisnis-8/'
ERROR - 2019-12-02 15:58:05 --> Could not find the language line "table_content"
ERROR - 2019-12-02 15:58:08 --> Could not find the language line "form_label_content"
ERROR - 2019-12-02 15:58:08 --> Severity: Notice --> Undefined index: content /home/u8936188/public_html/demo-profile-bisnis-8/application/views/mod/footer/view_edit.php 46
ERROR - 2019-12-02 15:58:08 --> Severity: Notice --> Undefined index: active /home/u8936188/public_html/demo-profile-bisnis-8/application/views/mod/footer/view_edit.php 63
ERROR - 2019-12-02 15:58:08 --> Could not find the language line "form_label_active"
ERROR - 2019-12-02 15:58:08 --> Could not find the language line "form_label_picture"
ERROR - 2019-12-02 15:58:08 --> Severity: Notice --> Undefined index: picture /home/u8936188/public_html/demo-profile-bisnis-8/application/views/mod/footer/view_edit.php 89
ERROR - 2019-12-02 15:58:08 --> Could not find the language line "form_label_picture"
ERROR - 2019-12-02 16:03:37 --> Severity: Notice --> Undefined variable: footer /home/u8936188/public_html/demo-profile-bisnis-8/application/views/themes/profile-bisnis-8-c15c115feb9638b5902bfa60dfb569eb/footer.php 9
ERROR - 2019-12-02 21:47:53 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-3/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-02 22:00:36 --> Severity: error --> Exception: syntax error, unexpected ''class=' (T_ENCAPSED_AND_WHITESPACE) /home/u8936188/public_html/demo-profile-bisnis-3/application/views/themes/profile-bisnis-3-01909b040050e65f8ffcf217d778ac62/home.php 206
ERROR - 2019-12-02 22:05:30 --> Severity: error --> Exception: syntax error, unexpected ''class="nobottommargin" ' (T_ENCAPSED_AND_WHITESPACE) /home/u8936188/public_html/demo-profile-bisnis-3/application/views/themes/profile-bisnis-3-01909b040050e65f8ffcf217d778ac62/home.php 205
ERROR - 2019-12-02 22:17:38 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-3/application/views/mod/homepage/view_edit.php 35
ERROR - 2019-12-02 22:33:08 --> Severity: Notice --> Undefined index: seotitle /home/u8936188/public_html/demo-profile-bisnis-3/application/views/mod/homepage/view_edit.php 35
