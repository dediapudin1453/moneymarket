<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-29 11:14:11 --> Could not find the language line "table_content"
ERROR - 2020-04-29 11:14:29 --> Could not find the language line "form_label_content"
ERROR - 2020-04-29 11:14:29 --> Severity: Notice --> Undefined index: content /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 46
ERROR - 2020-04-29 11:14:29 --> Severity: Notice --> Undefined index: active /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 63
ERROR - 2020-04-29 11:14:29 --> Could not find the language line "form_label_active"
ERROR - 2020-04-29 11:14:29 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 11:14:29 --> Severity: Notice --> Undefined index: picture /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 89
ERROR - 2020-04-29 11:14:29 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 11:15:27 --> Could not find the language line "table_content"
ERROR - 2020-04-29 12:26:30 --> Could not find the language line "table_content"
ERROR - 2020-04-29 12:29:18 --> Could not find the language line "form_label_content"
ERROR - 2020-04-29 12:29:18 --> Severity: Notice --> Undefined index: content /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 46
ERROR - 2020-04-29 12:29:18 --> Severity: Notice --> Undefined index: active /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 63
ERROR - 2020-04-29 12:29:18 --> Could not find the language line "form_label_active"
ERROR - 2020-04-29 12:29:18 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:29:18 --> Severity: Notice --> Undefined index: picture /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 89
ERROR - 2020-04-29 12:29:18 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:41:47 --> Could not find the language line "table_content"
ERROR - 2020-04-29 12:41:49 --> Could not find the language line "form_label_content"
ERROR - 2020-04-29 12:41:49 --> Severity: Notice --> Undefined index: content /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 48
ERROR - 2020-04-29 12:41:49 --> Severity: Notice --> Undefined index: active /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 65
ERROR - 2020-04-29 12:41:49 --> Could not find the language line "form_label_active"
ERROR - 2020-04-29 12:41:49 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:41:49 --> Severity: Notice --> Undefined index: picture /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 91
ERROR - 2020-04-29 12:41:49 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:41:55 --> Could not find the language line "form_label_content"
ERROR - 2020-04-29 12:41:55 --> Severity: Notice --> Undefined index: content /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 48
ERROR - 2020-04-29 12:41:55 --> Severity: Notice --> Undefined index: active /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 65
ERROR - 2020-04-29 12:41:55 --> Could not find the language line "form_label_active"
ERROR - 2020-04-29 12:41:55 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:41:55 --> Severity: Notice --> Undefined index: picture /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 91
ERROR - 2020-04-29 12:41:55 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:41:56 --> Could not find the language line "form_label_content"
ERROR - 2020-04-29 12:41:56 --> Severity: Notice --> Undefined index: content /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 48
ERROR - 2020-04-29 12:41:56 --> Severity: Notice --> Undefined index: active /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 65
ERROR - 2020-04-29 12:41:56 --> Could not find the language line "form_label_active"
ERROR - 2020-04-29 12:41:56 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:41:56 --> Severity: Notice --> Undefined index: picture /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 91
ERROR - 2020-04-29 12:41:56 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:41:57 --> Could not find the language line "form_label_content"
ERROR - 2020-04-29 12:41:57 --> Severity: Notice --> Undefined index: content /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 48
ERROR - 2020-04-29 12:41:57 --> Severity: Notice --> Undefined index: active /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 65
ERROR - 2020-04-29 12:41:57 --> Could not find the language line "form_label_active"
ERROR - 2020-04-29 12:41:57 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:41:57 --> Severity: Notice --> Undefined index: picture /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 91
ERROR - 2020-04-29 12:41:57 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:42:34 --> Could not find the language line "form_label_content"
ERROR - 2020-04-29 12:42:34 --> Severity: Notice --> Undefined index: content /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 48
ERROR - 2020-04-29 12:42:34 --> Severity: Notice --> Undefined index: active /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 65
ERROR - 2020-04-29 12:42:34 --> Could not find the language line "form_label_active"
ERROR - 2020-04-29 12:42:34 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:42:34 --> Severity: Notice --> Undefined index: picture /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/footer/view_edit.php 91
ERROR - 2020-04-29 12:42:34 --> Could not find the language line "form_label_picture"
ERROR - 2020-04-29 12:46:24 --> Could not find the language line "table_content"
ERROR - 2020-04-29 13:13:21 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-2-c8f9dca9bff38715b00d6ca721ead62f/home.php 34
ERROR - 2020-04-29 13:13:22 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-2-c8f9dca9bff38715b00d6ca721ead62f/home.php 34
ERROR - 2020-04-29 13:13:24 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-2-c8f9dca9bff38715b00d6ca721ead62f/home.php 34
ERROR - 2020-04-29 15:01:48 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-04-29 21:07:16 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-04-29 22:17:59 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-8-9e2617f08bf3455c0b988f273a34bcb8/footer.php 9
ERROR - 2020-04-29 22:18:41 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-8-9e2617f08bf3455c0b988f273a34bcb8/footer.php 9
ERROR - 2020-04-29 22:18:57 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-04-29 22:19:16 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-04-29 22:25:19 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-04-29 22:25:32 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-04-29 22:27:38 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-04-29 22:28:24 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-4-15a5e9889a0d14cbf4260b8b86ace255/footer.php 6
ERROR - 2020-04-29 22:29:14 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-8-9e2617f08bf3455c0b988f273a34bcb8/footer.php 9
ERROR - 2020-04-29 22:29:49 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-8-9e2617f08bf3455c0b988f273a34bcb8/footer.php 9
ERROR - 2020-04-29 22:30:33 --> Severity: Notice --> Undefined variable: footer /home/u8916311/public_html/demo-profile-bisnis-4/application/views/themes/profile-bisnis-8-9e2617f08bf3455c0b988f273a34bcb8/footer.php 9
ERROR - 2020-04-29 22:55:31 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
ERROR - 2020-04-29 23:52:20 --> Severity: Notice --> Undefined index: seotitle /home/u8916311/public_html/demo-profile-bisnis-4/application/views/mod/homepage/view_edit.php 35
