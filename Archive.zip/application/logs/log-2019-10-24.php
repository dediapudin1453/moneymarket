<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-24 07:48:30 --> 404 Page Not Found: 
ERROR - 2019-10-24 07:48:34 --> 404 Page Not Found: 
ERROR - 2019-10-24 07:48:36 --> 404 Page Not Found: 
ERROR - 2019-10-24 07:48:43 --> 404 Page Not Found: 
ERROR - 2019-10-24 13:45:36 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cifirecms\application\views\themes\company-profile-1-08f7740d0840322cb9b6a32cf5dd2843\home.php 381
ERROR - 2019-10-24 13:45:38 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cifirecms\application\views\themes\company-profile-1-08f7740d0840322cb9b6a32cf5dd2843\home.php 381
ERROR - 2019-10-24 13:45:40 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cifirecms\application\views\themes\company-profile-1-08f7740d0840322cb9b6a32cf5dd2843\home.php 381
ERROR - 2019-10-24 13:45:50 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cifirecms\application\views\themes\company-profile-1-08f7740d0840322cb9b6a32cf5dd2843\home.php 381
ERROR - 2019-10-24 13:46:16 --> Severity: Notice --> Undefined variable: res_post3a C:\xampp\htdocs\cifirecms\application\views\themes\company-profile-1-08f7740d0840322cb9b6a32cf5dd2843\home.php 320
ERROR - 2019-10-24 13:46:16 --> Severity: Notice --> Undefined variable: res_post3a C:\xampp\htdocs\cifirecms\application\views\themes\company-profile-1-08f7740d0840322cb9b6a32cf5dd2843\home.php 320
