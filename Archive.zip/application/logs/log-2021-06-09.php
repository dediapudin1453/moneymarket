<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-09 12:46:27 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_slider`
WHERE `active` = 'Y'
ERROR - 2021-06-09 12:59:00 --> Query error: MySQL server has gone away - Invalid query: SELECT *
FROM `t_slider`
WHERE `active` = 'Y'
