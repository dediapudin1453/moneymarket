<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-28 08:18:18 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/header.php 121
ERROR - 2021-07-28 08:18:18 --> Severity: Notice --> Undefined variable: titlecta /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-07-28 08:18:18 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-07-28 08:21:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/header.php 121
ERROR - 2021-07-28 08:21:32 --> Severity: Notice --> Undefined variable: titlecta /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
ERROR - 2021-07-28 08:21:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/u1476998/public_html/demoforex/application/views/themes/yasta-f72c25a3e4a274716c616b5da2bd726e/footer.php 45
