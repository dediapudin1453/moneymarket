<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['mod_title'] = 'Tag';
$lang['mod_title_all'] = 'All Tag';
$lang['mod_title_add'] = 'Add New';
$lang['mod_lang_1'] = 'Can input more than one tag ( , )';
$lang['table_id'] = 'Id';
$lang['table_title'] = 'Title';
$lang['table_count'] = 'Count';
$lang['table_action'] = 'Action';
$lang['form_label_tag'] = 'Tag';
$lang['form_message_add_success'] = 'Tag has been successfully added';
$lang['form_message_update_success'] = 'Tag has been successfully updated';
$lang['form_message_delete_success'] = 'Tag has been successfully deleted';
$lang['dialog_add_title'] = 'Add Tags';